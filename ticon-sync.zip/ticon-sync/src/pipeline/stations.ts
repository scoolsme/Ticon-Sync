import { AxiosInstance } from "axios";
import { readRows, Row } from "../excel/readRows";

// Helper to chunk array into groups
function chunkArray<T>(array: T[], size: number): T[][] {
  const result: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
}

export async function createStations(
  api: AxiosInstance,
  parentUid: string
) {

  console.log("Creating parallel idempotent Workstations");

  const rows: Row[] = readRows("TiConPEH API-TEST.xlsx");

  // PEH
  const pehRes = await api.get("/ticon-web/services/data/folders", {
    params: { code: "PEH" }
  });

  const peh = pehRes.data.entities.find(
    (f: any) => String(f.parentFolderUid) === String(parentUid)
  );

  if (!peh) throw new Error("PEH not found");

  // MA and OP
  const ma = (await api.get("/folders", { params: { code: "MA" } }))
    .data.entities.find((f: any) => f.parentFolderUid === peh.uid);

  const op = (await api.get("/folders", { params: { code: "OP" } }))
    .data.entities.find((f: any) => f.parentFolderUid === peh.uid);

  // Machines
  const machineRes = await api.get(
    "/ticon-web/services/data/resource-machine-elements",
    { params: { folderpath: ma.path } }
  );

  const machineMap = new Map<string, string>();
  machineRes.data.entities.forEach((m: any) =>
    machineMap.set(m.code.trim().toUpperCase(), m.uid)
  );

  // Operators
  const operatorRes = await api.get(
    "/ticon-web/services/data/resource-operator-elements",
    { params: { folderpath: op.path } }
  );

  const operatorMap = new Map<string, string>();
  operatorRes.data.entities.forEach((o: any) =>
    operatorMap.set(o.code.trim().toUpperCase(), o.uid)
  );

  // Group by line
  const grouped = new Map<string, Row[]>();

  for (const r of rows) {
    if (!grouped.has(r.lineCode)) grouped.set(r.lineCode, []);
    grouped.get(r.lineCode)!.push(r);
  }

  const stationList: any[] = [];

  // Build payload list
  for (const [lineCode, groupRows] of grouped.entries()) {

    const r = groupRows[0];

    const machineUid = machineMap.get(r.machineCode.trim().toUpperCase());
    const operatorUid = operatorMap.get(r.operatorCode.trim().toUpperCase());

    if (!machineUid || !operatorUid) continue;

    // Existence check
    const exists = await api.get(
      "/ticon-web/services/data/resource-station-elements",
      { params: { code: lineCode } }
    );

    if (exists.data.entities.length > 0) {
      console.log("Skip:", lineCode);
      continue;
    }

    stationList.push({
      Code: lineCode,
      folderUid: peh.uid,
      elementConfigurationUid: "ElementClassConfiguration-100033",
      Description: {
        language: "en-US",
        text: r.lineName
      },
      machinesOrOperators: [
        {
          row: {
            elementUid: operatorUid,
            typeEnum: "ResourceOperator",
            factor: "1",
            orderNumber: 1,
            rowType: "MACHINEOROPERATORREFERENCE"
          }
        },
        {
          row: {
            elementUid: machineUid,
            typeEnum: "ResourceMachine",
            factor: "1",
            orderNumber: 1,
            rowType: "MACHINEOROPERATORREFERENCE"
          }
        }
      ]
    });
  }

  console.log("Stations to create:", stationList.length);

  // Parallel execution with batch size 3
  const chunks = chunkArray(stationList, 3);

  for (const batch of chunks) {

    console.log("Processing batch of", batch.length);

    await Promise.all(
      batch.map(async (payload) => {
        try {
          await api.post(
            "/ticon-web/services/data/resource-station-elements",
            [payload]
          );
          console.log("Created:", payload.Code);
        } catch (err: any) {
          console.log("Failed:", payload.Code);
          console.log(err.response?.data);
        }
      })
    );
  }

  console.log("Parallel execution completed");
}