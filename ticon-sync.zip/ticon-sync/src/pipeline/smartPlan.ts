import { AxiosInstance } from "axios";
import { loadRuntimeContext, type RuntimeContext } from "../agents/runtimeContextAgent";

export type PlanItem = {
  type: "AREA" | "LINE" | "MACHINE" | "OPERATOR";
  code: string;
  name?: string;
  parentCode?: string;
  action: "CREATE" | "EXISTS";
  reason?: string;
};

type CheckStatus = "OK" | "WARNING" | "FAILED";

type RiskLevel = "LOW" | "MEDIUM" | "HIGH";

type PlanningCheck = {
  name: string;
  status: CheckStatus;
  detail: string;
};

type PlanSummary = {
  area: { create: number; exists: number };
  line: { create: number; exists: number };
  machine: { create: number; exists: number };
  operator: { create: number; exists: number };
  totalCreate: number;
  totalExists: number;
};

class HierarchyPlanningAgent {
  private readonly checks: PlanningCheck[] = [];

  private readonly plan: PlanItem[] = [];

  private readonly planDebugLines: string[] = [];

  private context?: RuntimeContext;

  constructor(
    private readonly api: AxiosInstance,
    private readonly uniques: any,
    private readonly rootUid: string,
    runtimeContext?: RuntimeContext
  ) {
    this.context = runtimeContext;
  }

  public async build(): Promise<{ plan: PlanItem[]; riskLevel: RiskLevel }> {
    this.log("Starting smart plan build");

    await this.loadRuntimeContext();
    this.validateInputUniqueness();
    this.planAreas();
    this.planLines();
    this.planMachines();
    this.planOperators();
    this.validatePlanGeneration();

    const riskLevel = this.calculateRiskLevel();
    this.logSummary(riskLevel);
    this.log(`Planning complete with risk level ${riskLevel}`);

    if (riskLevel === "HIGH") {
      throw new Error(this.buildFailureMessage());
    }

    return {
      plan: this.plan,
      riskLevel
    };
  }

  private log(message: string): void {
    console.log(`[HierarchyPlanningAgent] ${message}`);
  }

  private debug(message: string): void {
    if (process.env.LOG_LEVEL === "debug") {
      this.log(message);
    }
  }

  private addCheck(name: string, status: CheckStatus, detail: string): void {
    this.checks.push({ name, status, detail });
    if (status !== "OK") {
      this.log(`${status} ${name}: ${detail}`);
    } else {
      this.debug(`OK ${name}: ${detail}`);
    }
  }

  private addPlanItem(item: PlanItem): void {
    this.plan.push(item);

    if (process.env.LOG_LEVEL === "debug") {
      const reason = item.reason ? ` | ${item.reason}` : "";
      this.planDebugLines.push(`${item.type} ${item.code} => ${item.action}${reason}`);
    }
  }

  private async loadRuntimeContext(): Promise<void> {
    this.log("Loading runtime context");

    if (!this.context) {
      this.context = await loadRuntimeContext(this.api, this.rootUid, {
        includeMachines: true,
        includeOperators: true
      });
    }

    if (this.context.folders.length === 0) {
      this.addCheck(
        "FolderInventoryLoad",
        "FAILED",
        "No folders were returned from TiCon"
      );
      return;
    }

    this.addCheck(
      "FolderInventoryLoad",
      "OK",
      `Loaded ${this.context.folders.length} folders from TiCon`
    );

    this.addCheck(
      "PEHExists",
      "OK",
      `PEH found with uid ${this.context.pehFolder.uid}`
    );
    this.addCheck(
      "MAExists",
      "OK",
      `MA found with uid ${this.context.maFolder.uid}`
    );
    this.addCheck(
      "OPExists",
      "OK",
      `OP found with uid ${this.context.opFolder.uid}`
    );

    this.addCheck(
      "MachineLoad",
      "OK",
      `Loaded ${this.context.machineSet.size} existing machines from ${this.context.machinePath}`
    );

    this.addCheck(
      "OperatorLoad",
      "OK",
      `Loaded ${this.context.operatorSet.size} existing operators from ${this.context.operatorPath}`
    );
  }

  private validateInputUniqueness(): void {
    const issues: string[] = [];

    for (const [code] of this.uniques.areas.entries()) {
      if (!String(code).trim()) {
        issues.push("blank area code");
      }
    }

    for (const [code, data] of this.uniques.lines.entries()) {
      if (!String(code).trim()) {
        issues.push("blank line code");
      }

      if (!String(data.areaCode || "").trim()) {
        issues.push(`missing parent area for line ${code}`);
      }
    }

    for (const code of this.uniques.machines) {
      if (!String(code).trim()) {
        issues.push("blank machine code");
      }
    }

    for (const code of this.uniques.operators) {
      if (!String(code).trim()) {
        issues.push("blank operator code");
      }
    }

    if (issues.length > 0) {
      this.addCheck(
        "InputUniqueness",
        "FAILED",
        issues.join(", ")
      );
      return;
    }

    this.addCheck(
      "InputUniqueness",
      "OK",
      "Input collections are unique and non-empty"
    );
  }

  private planAreas(): void {
    const context = this.getContext();

    for (const [code, name] of this.uniques.areas.entries()) {
      const exists = context.folderKeySet.has(`${code}|${this.rootUid}`);

      this.addPlanItem({
        type: "AREA",
        code,
        name,
        action: exists ? "EXISTS" : "CREATE",
        reason: exists
          ? `AREA ${code} already exists under the provided root`
          : `AREA ${code} does not exist under the provided root`
      });
    }

    const areaUidMap = new Map<string, string>();

    for (const [code] of this.uniques.areas.entries()) {
      const uid = context.folderUidByKey.get(`${code}|${this.rootUid}`);

      if (uid) {
        areaUidMap.set(code, uid);
      }
    }

    this.log(`Resolved ${areaUidMap.size} existing areas for line planning`);
  }

  private validateLineParentMapping(): void {
    const context = this.getContext();
    const missingParents: string[] = [];

    for (const [code, data] of this.uniques.lines.entries()) {
      const areaUid = context.folderUidByKey.get(`${data.areaCode}|${this.rootUid}`);

      if (!areaUid) {
        missingParents.push(`${code}->${data.areaCode}`);
      }
    }

    if (missingParents.length > 0) {
      this.addCheck(
        "LineParentMapping",
        "WARNING",
        `Missing parent mapping for ${missingParents.length} line(s): ${missingParents.join(", ")}`
      );
      return;
    }

    this.addCheck(
      "LineParentMapping",
      "OK",
      "All line parents are mapped to existing areas"
    );
  }

  private planLines(): void {
    const context = this.getContext();
    const areaUidMap = new Map<string, string>();

    for (const [code] of this.uniques.areas.entries()) {
      const uid = context.folderUidByKey.get(`${code}|${this.rootUid}`);

      if (uid) {
        areaUidMap.set(code, uid);
      }
    }

    for (const [code, data] of this.uniques.lines.entries()) {
      const areaUid = areaUidMap.get(data.areaCode);

      const exists = areaUid
        ? context.folderKeySet.has(`${code}|${areaUid}`)
        : false;

      this.addPlanItem({
        type: "LINE",
        code,
        name: data.name,
        parentCode: data.areaCode,
        action: exists ? "EXISTS" : "CREATE",
        reason: exists
          ? `LINE ${code} already exists under AREA ${data.areaCode}`
          : areaUid
            ? `LINE ${code} does not exist under AREA ${data.areaCode}`
            : `AREA ${data.areaCode} is missing, so LINE ${code} will be created as part of the hierarchy`
      });
    }

      this.validateLineParentMapping();
  }

  private planMachines(): void {
    const context = this.getContext();

    for (const code of this.uniques.machines) {
      const exists = context.machineSet.has(code);

        this.addPlanItem({
        type: "MACHINE",
        code,
        action: exists ? "EXISTS" : "CREATE",
        reason: exists
          ? `MACHINE ${code} already exists`
          : `MACHINE ${code} does not exist`
      });
    }
  }

  private planOperators(): void {
    const context = this.getContext();

    for (const code of this.uniques.operators) {
      const exists = context.operatorSet.has(code);

        this.addPlanItem({
        type: "OPERATOR",
        code,
        action: exists ? "EXISTS" : "CREATE",
        reason: exists
          ? `OPERATOR ${code} already exists`
          : `OPERATOR ${code} does not exist`
      });
    }
  }

    private validatePlanGeneration(): void {
      const summary = this.buildSummary();

      this.addCheck(
        "PlanGeneration",
        "OK",
        `Generated ${this.plan.length} plan items`
      );

      const highCreateCount =
        summary.totalCreate >= 50 &&
        summary.totalCreate / Math.max(1, this.plan.length) >= 0.85;

      if (highCreateCount) {
        this.addCheck(
          "CreateVolume",
          "WARNING",
          `High create volume detected: ${summary.totalCreate} of ${this.plan.length} items`
        );
      } else {
        this.addCheck(
          "CreateVolume",
          "OK",
          `Create volume is within expected bounds: ${summary.totalCreate} of ${this.plan.length} items`
        );
      }
    }

    private buildSummary(): PlanSummary {
      const summary: PlanSummary = {
        area: { create: 0, exists: 0 },
        line: { create: 0, exists: 0 },
        machine: { create: 0, exists: 0 },
        operator: { create: 0, exists: 0 },
        totalCreate: 0,
        totalExists: 0
      };

      for (const item of this.plan) {
        const bucket = item.type.toLowerCase() as keyof Pick<PlanSummary, "area" | "line" | "machine" | "operator">;

        if (item.action === "CREATE") {
          summary[bucket].create += 1;
          summary.totalCreate += 1;
        } else {
          summary[bucket].exists += 1;
          summary.totalExists += 1;
        }
      }

      return summary;
    }

    private logSummary(riskLevel: RiskLevel): void {
      const summary = this.buildSummary();

      this.log("Plan summary");
      this.log(`  Areas: CREATE ${summary.area.create}, EXISTS ${summary.area.exists}`);
      this.log(`  Lines: CREATE ${summary.line.create}, EXISTS ${summary.line.exists}`);
      this.log(`  Machines: CREATE ${summary.machine.create}, EXISTS ${summary.machine.exists}`);
      this.log(`  Operators: CREATE ${summary.operator.create}, EXISTS ${summary.operator.exists}`);

      if (process.env.LOG_LEVEL === "debug" && this.planDebugLines.length > 0) {
        for (const line of this.planDebugLines) {
          this.log(line);
        }
      }
    }

  private calculateRiskLevel(): RiskLevel {
    if (this.checks.some(check => check.status === "FAILED")) {
      return "HIGH";
    }

    if (this.checks.some(check => check.status === "WARNING")) {
      return "MEDIUM";
    }

    return "LOW";
  }

  private buildFailureMessage(): string {
    const failedChecks = this.checks
      .filter(check => check.status === "FAILED")
      .map(check => `${check.name}: ${check.detail}`);

    return [
      "[HierarchyPlanningAgent] Planning failed with HIGH risk",
      ...failedChecks
    ].join("\n");
  }

  private getContext(): RuntimeContext {
    if (!this.context) {
      throw new Error("Runtime context not initialized");
    }

    return this.context;
  }
}

// ---------- MAIN ----------
export async function buildSmartPlan(
  api: AxiosInstance,
  uniques: any,
  rootUid: string,
  runtimeContext?: RuntimeContext
): Promise<PlanItem[]> {
  const agent = new HierarchyPlanningAgent(api, uniques, rootUid, runtimeContext);
  const result = await agent.build();

  return result.plan;
}
