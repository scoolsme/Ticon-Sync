
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { existsSync } from "fs";
import * as XLSX from "xlsx";
import { createTiconClient } from "../ticon/client";
import { loadRuntimeContext } from "../agents/runtimeContextAgent";

const REQUIRED_COLUMNS = [
  "ProductionAreaId",
  "Production Area Name",
  "ProductionLineID",
  "ProductionLineName",
  "SAP Workcenter",
  "Workstation Name",
  "Workstation Sequence",
  "Equipment-LLL",
  "Operator"
] as const;

export type ValidateInputResult = {
  rootUid: string;
  pehUid: string;
  maUid: string;
  opUid: string;
  excelPath: string;
};

function normalizeRootUid(rootUid: string): string {
  const trimmed = String(rootUid || "").trim();

  if (!trimmed) {
    throw new Error("Root UID is required");
  }

  if (trimmed.startsWith("Folder-")) {
    return trimmed;
  }

  return `Folder-${trimmed}`;
}

function assertExcelReady(excelPath: string): void {
  if (!existsSync(excelPath)) {
    throw new Error(`Excel file not found: ${excelPath}`);
  }

  const workbook = XLSX.readFile(excelPath);

  if (!workbook.SheetNames.includes("Scripts")) {
    throw new Error("Excel sheet 'Scripts' not found");
  }

  const scriptsSheet = workbook.Sheets["Scripts"];
  const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(scriptsSheet);

  if (rows.length === 0) {
    throw new Error("Excel sheet 'Scripts' is empty");
  }

  const firstRow = rows[0] || {};
  const headerSet = new Set(Object.keys(firstRow));

  const missing = REQUIRED_COLUMNS.filter(col => !headerSet.has(col));

  if (missing.length > 0) {
    throw new Error(`Missing required columns: ${missing.join(", ")}`);
  }
}

export async function validateInput(
  api: any,
  rootUid: string,
  excelPath: string
): Promise<ValidateInputResult> {
  const normalizedRootUid = normalizeRootUid(rootUid);

  console.log("    Input validation started");
  console.log("    Root UID (normalized):", normalizedRootUid);
  console.log("    Excel file:", excelPath);

  console.log("    Checking Excel file and structure...");
  assertExcelReady(excelPath);
  console.log("    Excel validation OK");

  console.log("    Checking TiCon folder hierarchy...");
  let context: Awaited<ReturnType<typeof loadRuntimeContext>>;

  try {
    context = await loadRuntimeContext(api, normalizedRootUid, {
      includeMachines: false,
      includeOperators: false
    });
  } catch (err: any) {
    const message = String(err?.message || "");

    if (message.includes("PEH not found")) {
      throw new Error("PEH folder not found under root UID");
    }

    if (message.includes("MA not found") || message.includes("OP not found")) {
      throw new Error("MA or OP folder not found under PEH");
    }

    throw err;
  }

  console.log("    TiCon hierarchy OK");
  console.log("      PEH:", context.pehFolder.uid);
  console.log("      MA :", context.maFolder.uid);
  console.log("      OP :", context.opFolder.uid);
  console.log("    Input validation completed");

  return {
    rootUid: normalizedRootUid,
    pehUid: context.pehFolder.uid,
    maUid: context.maFolder.uid,
    opUid: context.opFolder.uid,
    excelPath
  };
}

async function runFromCli(): Promise<void> {
  const rawUid = process.argv[2];
  const excelPath = process.argv[3] || "TiConPEH API-TEST.xlsx";

  if (!rawUid) {
    console.error("Provide root UID as process.argv[2]");
    process.exit(1);
  }

  const normalizedRootUid = normalizeRootUid(rawUid);

  console.log("    Creating TiCon client...");
  const api = createTiconClient();
  console.log("    TiCon client ready");

  await validateInput(api, normalizedRootUid, excelPath);
}

runFromCli().catch((err: any) => {
  console.error("Validation failed:", err.response?.data || err.message);
  process.exit(1);
});
