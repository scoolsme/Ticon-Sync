import { generatePlanWithLLM } from "../agents/llmPlanAgent";

/**
 * Temporary test script for LLMPlanAgent
 * Tests the LLM plan generation with hardcoded input
 */
async function testLLMPlanAgent(): Promise<void> {
  console.log("[TestLLMPlanAgent] Starting LLM plan agent test");

  const input = {
    areas: ["A1"],
    lines: [{ code: "L1", parentCode: "A1" }],
    machines: ["M1"],
    operators: ["O1"],
    existingContext: {
      areas: [],
      lines: [],
      machines: [],
      operators: []
    }
  };

  console.log("[TestLLMPlanAgent] Input:");
  console.log(JSON.stringify(input, null, 2));

  try {
    const plan = await generatePlanWithLLM(input);

    console.log("[TestLLMPlanAgent] Generated plan:");
    console.log(JSON.stringify(plan, null, 2));

    console.log("[TestLLMPlanAgent] Test completed successfully");
  } catch (error: any) {
    console.error("[TestLLMPlanAgent] Test failed:");
    console.error(error.message);
    process.exit(1);
  }
}

testLLMPlanAgent();
