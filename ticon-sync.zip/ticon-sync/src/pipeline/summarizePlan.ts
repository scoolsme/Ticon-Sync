import { existsSync, readFileSync } from "fs";

type PlanType = "AREA" | "LINE" | "MACHINE" | "OPERATOR";
type PlanAction = "CREATE" | "EXISTS";

type PlanItem = {
  type: PlanType;
  action: PlanAction;
};

const TYPES: PlanType[] = ["AREA", "LINE", "MACHINE", "OPERATOR"];

function loadPlan(planPath: string): PlanItem[] {
  if (!existsSync(planPath)) {
    throw new Error(`Plan file not found: ${planPath}`);
  }

  const raw = readFileSync(planPath, "utf-8");
  const parsed = JSON.parse(raw);

  if (!Array.isArray(parsed)) {
    throw new Error("Invalid plan file format. Expected an array.");
  }

  return parsed as PlanItem[];
}

function countByTypeAndAction(plan: PlanItem[], type: PlanType, action: PlanAction): number {
  return plan.filter(item => item.type === type && item.action === action).length;
}

export function summarizePlan(planPath: string = "artifacts/smartPlan.json"): void {
  console.log("    SmartPlan summary started");
  console.log("    Plan file:", planPath);

  const plan = loadPlan(planPath);

  console.log("    Summary:");

  for (const type of TYPES) {
    const createCount = countByTypeAndAction(plan, type, "CREATE");
    const existsCount = countByTypeAndAction(plan, type, "EXISTS");

    if (createCount === 0) {
      console.log(`      ${type}: no changes needed`);
    } else {
      console.log(`      ${type} to create: ${createCount}`);
    }

    console.log(`        ${type} existing: ${existsCount}`);
  }

  console.log("    SmartPlan summary completed");
}

function runFromCli(): void {
  const planPath = process.argv[2] || "artifacts/smartPlan.json";
  summarizePlan(planPath);
}

try {
  runFromCli();
} catch (err: any) {
  console.error("Summary failed:", err.message || err);
  process.exit(1);
}
