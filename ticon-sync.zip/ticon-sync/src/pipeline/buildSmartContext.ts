import { AxiosInstance } from "axios";

export type PlanItem = {
  type: "AREA" | "LINE" | "MACHINE" | "OPERATOR";
  code: string;
  action: "CREATE" | "EXISTS";
};

export type FolderEntity = {
  uid: string;
  code: string;
  parentFolderUid?: string;
};

export type ResourceEntity = {
  uid: string;
  code: string;
  folderUid: string;
};

export type SmartContext = {
  plan: PlanItem[];
  folderMap: Map<string, string>;
  machineMap: Map<string, string>;
  operatorMap: Map<string, string>;
};

// ---------- PAGINATION ----------

async function fetchAll<T>(
  api: AxiosInstance,
  url: string
): Promise<T[]> {

  const pageSize = 500;
  let skip = 0;
  let all: T[] = [];

  while (true) {
    const res = await api.get<{ entities: T[] }>(url, {
      params: { pageSize, skip }
    });

    const data = res.data.entities;
    all = all.concat(data);

    if (data.length < pageSize) break;

    skip += pageSize;
  }

  return all;
}

// ---------- MAIN ----------

export async function buildSmartContext(
  api: AxiosInstance,
  plan: PlanItem[]
): Promise<SmartContext> {

  console.log("Fetching dataset once (scoped)");

  const folders = await fetchAll<FolderEntity>(
    api,
    "/ticon-web/services/data/folders"
  );

  const machines = await fetchAll<ResourceEntity>(
    api,
    "/ticon-web/services/data/resource-machine-elements"
  );

  const operators = await fetchAll<ResourceEntity>(
    api,
    "/ticon-web/services/data/resource-operator-elements"
  );

  // ✅ Folder map (code + parent)
  const folderMap = new Map<string, string>();
  folders.forEach(f => {
    folderMap.set(`${f.code}|${f.parentFolderUid}`, f.uid);
  });

  // ✅ Scoped machine map (code + folder)
  const machineMap = new Map<string, string>();
  machines.forEach(m => {
    machineMap.set(`${m.code}|${m.folderUid}`, m.uid);
  });

  // ✅ Scoped operator map
  const operatorMap = new Map<string, string>();
  operators.forEach(o => {
    operatorMap.set(`${o.code}|${o.folderUid}`, o.uid);
  });

  console.log("SmartContext ready (scoped)");

  return {
    plan,
    folderMap,
    machineMap,
    operatorMap
  };
}