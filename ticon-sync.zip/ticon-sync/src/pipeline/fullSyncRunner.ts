import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);

import { writeFileSync } from "fs";
import { createTiconClient } from "../ticon/client";
import { readRows } from "../excel/readRows";
import { extractUniques } from "../utils/extract";
import { loadRuntimeContext, type RuntimeContext } from "../agents/runtimeContextAgent";
import { buildSmartPlan, type PlanItem } from "./smartPlan";
import { executePlan } from "./executor";
import { runStationRunner } from "./stationRunner";
import { generatePlanWithLLM } from "../agents/llmPlanAgent";

function normalizeRootUid(rootUid: string): string {
  const trimmed = String(rootUid || "").trim();

  if (!trimmed) {
    throw new Error("Provide root UID");
  }

  if (trimmed.startsWith("Folder-")) {
    return trimmed;
  }

  return `Folder-${trimmed}`;
}

/**
 * Check if plan-only mode is enabled via CLI flag or environment variable
 */
function isPlanOnlyMode(): boolean {
  // Check CLI flag
  if (process.argv.includes("--plan-only")) {
    return true;
  }

  // Check environment variable
  if (process.env.FULLSYNC_PLAN_ONLY === "true") {
    return true;
  }

  return false;
}

export async function runFullSyncRunner(rootUid: string): Promise<void> {
  const normalizedRootUid = normalizeRootUid(rootUid);

  console.log("[FullSyncAgent] Full sync started");
  console.log(`[FullSyncAgent] Root UID: ${normalizedRootUid}`);

  const api = createTiconClient();

  console.log("[FullSyncAgent] Reading Excel input");
  const rows = readRows("TiConPEH API-TEST.xlsx");
  const uniques = extractUniques(rows);

  console.log("[FullSyncAgent] Loading runtime context");
  const runtimeContext = await loadRuntimeContext(api, normalizedRootUid, {
    includeMachines: true,
    includeOperators: true
  });

  console.log("[FullSyncAgent] Building smart plan");

  let smartPlan: PlanItem[];

  // Check if LLM plan mode is enabled
  if (process.env.USE_LLM_PLAN === "true") {
    try {
      console.log("[FullSyncAgent] Using LLM plan");

      // Build existingContext for LLM plan agent
      // AREA exists when folderKeySet contains: <areaCode>|<rootUid>
      const existingAreas = Array.from(uniques.areas.keys()).filter((areaCode) =>
        runtimeContext.folderKeySet.has(`${areaCode}|${normalizedRootUid}`)
      );

      // LINE exists when folderKeySet contains: <lineCode>|<parentAreaUid>
      const existingLines = Array.from(uniques.lines.entries())
        .filter(([lineCode, lineData]) => {
          const parentAreaCode = lineData.areaCode;
          if (!parentAreaCode) return false;
          // Get parent area UID from the mapping
          const parentAreaUid = runtimeContext.folderUidByKey.get(
            `${parentAreaCode}|${normalizedRootUid}`
          );
          if (!parentAreaUid) return false;
          // Check if line exists under parent area
          return runtimeContext.folderKeySet.has(`${lineCode}|${parentAreaUid}`);
        })
        .map(([lineCode]) => lineCode);

      if (process.env.LOG_LEVEL === "debug") {
        console.log(`[FullSyncAgent] LLM existing context areas: ${existingAreas.length}`);
        console.log(`[FullSyncAgent] LLM existing context lines: ${existingLines.length}`);
        console.log(
          `[FullSyncAgent] LLM existing context machines: ${runtimeContext.machineSet.size}`
        );
        console.log(
          `[FullSyncAgent] LLM existing context operators: ${runtimeContext.operatorSet.size}`
        );
      }

      // Build input for LLM plan agent
      const llmInput = {
        areas: Array.from(uniques.areas.keys()),
        lines: Array.from(uniques.lines.entries()).map(([code, data]) => ({
          code,
          parentCode: data.areaCode
        })),
        machines: Array.from(uniques.machines),
        operators: Array.from(uniques.operators),
        existingContext: {
          areas: existingAreas,
          lines: existingLines,
          machines: Array.from(runtimeContext.machineSet),
          operators: Array.from(runtimeContext.operatorSet)
        }
      };

      // Call LLM plan agent
      smartPlan = await generatePlanWithLLM(llmInput);
    } catch (error: any) {
      console.log("[FullSyncAgent] LLM plan failed");
      console.log(`[FullSyncAgent] Error: ${error.message}`);

      // Check if fallback execution is explicitly allowed
      if (process.env.ALLOW_LLM_FALLBACK_EXECUTION === "true") {
        console.log(
          "[FullSyncAgent] LLM plan failed, falling back to default planner because ALLOW_LLM_FALLBACK_EXECUTION=true"
        );

        // Fall back to default planner
        smartPlan = await buildSmartPlan(
          api,
          {
            areas: uniques.areas,
            lines: uniques.lines,
            machines: Array.from(uniques.machines),
            operators: Array.from(uniques.operators)
          },
          normalizedRootUid,
          runtimeContext
        );
      } else {
        // Fail safely without executing
        throw new Error(
          "LLM plan failed. Execution stopped. " +
            "Set ALLOW_LLM_FALLBACK_EXECUTION=true to allow deterministic fallback execution."
        );
      }
    }
  } else {
    console.log("[FullSyncAgent] Using default planner");

    smartPlan = await buildSmartPlan(
      api,
      {
        areas: uniques.areas,
        lines: uniques.lines,
        machines: Array.from(uniques.machines),
        operators: Array.from(uniques.operators)
      },
      normalizedRootUid,
      runtimeContext
    );
  }

  writeFileSync("artifacts/smartPlan.json", JSON.stringify(smartPlan, null, 2));
  console.log("[FullSyncAgent] Smart plan written to artifacts/smartPlan.json");

  // Check if plan-only mode is enabled
  if (isPlanOnlyMode()) {
    console.log(
      "[FullSyncAgent] Plan-only mode enabled. Execution and station sync skipped."
    );
    return;
  }

  console.log("[FullSyncAgent] Executing plan");
  await executePlan(api, normalizedRootUid, "artifacts/smartPlan.json", runtimeContext);

  const shouldReloadForStations = smartPlan.some(
    (item: PlanItem) =>
      item.action === "CREATE" &&
      (item.type === "MACHINE" || item.type === "OPERATOR")
  );

  let stationRuntimeContext: RuntimeContext = runtimeContext;

  if (shouldReloadForStations) {
    console.log("[FullSyncAgent] Reloading runtime context before station sync");
    stationRuntimeContext = await loadRuntimeContext(api, normalizedRootUid, {
      includeMachines: true,
      includeOperators: true
    });
  }

  console.log("[FullSyncAgent] Running station sync");
  console.log("[FullSyncAgent] Sharing runtime context with StationRunnerAgent");
  await runStationRunner(normalizedRootUid, {
    api,
    runtimeContext: stationRuntimeContext
  });

  console.log("[FullSyncAgent] Full sync completed");
}

// Only run as a script if this is the main module being executed directly
if (require.main === module) {
  runFullSyncRunner(process.argv[2]).catch(err => {
    console.error("[FullSyncAgent] Full sync failed:", err.response?.data || err.message);
    process.exit(1);
  });
}
