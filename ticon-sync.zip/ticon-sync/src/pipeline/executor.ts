import { readFileSync } from "fs";
import { PlanItem } from "./smartPlan";
import {
  loadRuntimeContext,
  fetchRuntimeEntities,
  type RuntimeContext
} from "../agents/runtimeContextAgent";

// ---------- CONFIG CONSTANTS ----------
const CONFIG = {
  MACHINE: "ElementClassConfiguration-71201",
  OPERATOR: "ElementClassConfiguration-71101"
};

const API = {
  FOLDERS: "/ticon-web/services/data/folders",
  MACHINES: "/ticon-web/services/data/resource-machine-elements",
  OPERATORS: "/ticon-web/services/data/resource-operator-elements"
};

// ---------- CREATE FOLDER ----------
async function createFolder(
  api: any,
  code: string,
  parentUid: string,
  name: string
): Promise<string> {
  const res = await api.post(
    API.FOLDERS,
    [
      {
        Code: code,
        parentfolderUid: parentUid,
        Description: {
          language: "en-US",
          text: name
        }
      }
    ]
  );

  return res.data.entities[0].uid;
}

// ---------- BATCH ----------
async function processInBatches<T>(
  items: T[],
  batchSize: number,
  handler: (batch: T[], batchNumber: number) => Promise<void>
): Promise<void> {
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchNumber = Math.floor(i / batchSize) + 1;

    console.log(`[ExecutionAgent] Processing batch ${batchNumber}`);
    await handler(batch, batchNumber);
  }
}

// ---------- LOG API ERROR ----------
function logApiError(label: string, err: any): void {
  console.log(label);

  if (err.response?.data) {
    console.log(JSON.stringify(err.response.data, null, 2));
    return;
  }

  console.log(err.message || err);
}

type PlanSummary = {
  area: { create: number; exists: number };
  line: { create: number; exists: number };
  machine: { create: number; exists: number };
  operator: { create: number; exists: number };
  totalCreate: number;
  totalExists: number;
};

type GuardStatus = "OK" | "WARNING" | "FAILED";

type GuardRiskLevel = "LOW" | "MEDIUM" | "HIGH";

type GuardIssue = {
  name: string;
  status: GuardStatus;
  detail: string;
};

class ExecutionAgent {
  private readonly issues: GuardIssue[] = [];

  constructor(
    private readonly api: any,
    private readonly rootUid: string,
    private readonly planPath: string,
    private readonly runtimeContext?: RuntimeContext
  ) {}

  public async run(): Promise<void> {
    this.log("Execution started");

    const plan: PlanItem[] = JSON.parse(
      readFileSync(this.planPath, "utf-8")
    );

    const validation = this.validate(plan);
    this.log(`Execution approved with risk level ${validation.riskLevel}`);

    const createItems = plan.filter(item => item.action === "CREATE");

    if (createItems.length === 0) {
      this.log("Nothing to create");
      return;
    }

    const areas = createItems.filter(item => item.type === "AREA");
    const lines = createItems.filter(item => item.type === "LINE");
    const machinesFromPlan = createItems.filter(item => item.type === "MACHINE");
    const operatorsFromPlan = createItems.filter(item => item.type === "OPERATOR");

    this.log(`Areas to create: ${areas.length}`);
    this.log(`Lines to create: ${lines.length}`);

    const foldersBeforeCreate = await fetchRuntimeEntities(
      this.api,
      API.FOLDERS,
      {},
      "folders"
    );

    const areaMap = this.buildAreaMap(foldersBeforeCreate);
    await this.createAreas(areaMap, areas);
    await this.createLines(areaMap, lines, foldersBeforeCreate);

    const includeMachines = machinesFromPlan.length > 0;
    const includeOperators = operatorsFromPlan.length > 0;

    if (!includeMachines && !includeOperators) {
      return;
    }

    const context = await this.getRuntimeContext(includeMachines, includeOperators);

    await this.executeResourceCreation(
      "Machines",
      machinesFromPlan,
      context.machineSet,
      context.maFolder.uid,
      CONFIG.MACHINE,
      API.MACHINES
    );

    await this.executeResourceCreation(
      "Operators",
      operatorsFromPlan,
      context.operatorSet,
      context.opFolder.uid,
      CONFIG.OPERATOR,
      API.OPERATORS
    );
  }

  private validate(plan: unknown): { riskLevel: GuardRiskLevel; summary: PlanSummary } {
    this.log("Validating loaded plan");

    if (!Array.isArray(plan)) {
      this.addIssue("PlanShape", "FAILED", "Loaded plan is not an array");
      throw new Error(this.buildFailureMessage());
    }

    const summary = this.buildSummary(plan);
    let hasHighCreateCount = false;

    for (let index = 0; index < plan.length; index += 1) {
      const item = plan[index] as PlanItem;

      if (!item || typeof item !== "object") {
        this.addIssue(
          `PlanItem:${index}`,
          "FAILED",
          `Plan item at index ${index} is not an object`
        );
        continue;
      }

      if (item.action !== "CREATE" && item.action !== "EXISTS") {
        this.addIssue(
          `Action:${item.code || index}`,
          "FAILED",
          `Invalid action ${String(item.action)} for ${item.type || "unknown"} ${item.code || index}`
        );
      }

      if (
        item.type !== "AREA" &&
        item.type !== "LINE" &&
        item.type !== "MACHINE" &&
        item.type !== "OPERATOR"
      ) {
        this.addIssue(
          `Type:${item.code || index}`,
          "FAILED",
          `Invalid type ${String(item.type)} for ${item.code || index}`
        );
      }

      if (item.type === "LINE" && item.action === "CREATE" && !item.parentCode) {
        this.addIssue(
          `LineParent:${item.code || index}`,
          "FAILED",
          `CREATE LINE ${item.code || index} is missing parentCode`
        );
      }
    }

    const createCount = summary.totalCreate;
    const planLength = plan.length;

    if (planLength > 0) {
      const createRatio = createCount / planLength;
      hasHighCreateCount = createCount >= 50 && createRatio >= 0.85;
    }

    if (hasHighCreateCount) {
      this.addIssue(
        "CreateCount",
        "WARNING",
        `High create count detected: ${createCount} of ${planLength} items`
      );
    } else {
      this.addIssue(
        "CreateCount",
        "OK",
        `Create count summarized: ${createCount} of ${planLength} items`
      );
    }

    const riskLevel = this.calculateRiskLevel(hasHighCreateCount);

    this.log("Plan summary");
    this.log(`  Areas: CREATE ${summary.area.create}, EXISTS ${summary.area.exists}`);
    this.log(`  Lines: CREATE ${summary.line.create}, EXISTS ${summary.line.exists}`);
    this.log(`  Machines: CREATE ${summary.machine.create}, EXISTS ${summary.machine.exists}`);
    this.log(`  Operators: CREATE ${summary.operator.create}, EXISTS ${summary.operator.exists}`);
    this.log(`  Total CREATE: ${summary.totalCreate}`);
    this.log(`Risk level: ${riskLevel}`);

    if (riskLevel === "HIGH") {
      throw new Error(this.buildFailureMessage());
    }

    return { riskLevel, summary };
  }

  private log(message: string): void {
    console.log(`[ExecutionAgent] ${message}`);
  }

  private addIssue(name: string, status: GuardStatus, detail: string): void {
    this.issues.push({ name, status, detail });

    if (status !== "OK") {
      this.log(`${status} ${name}: ${detail}`);
    }
  }

  private calculateRiskLevel(hasHighCreateCount: boolean): GuardRiskLevel {
    if (this.issues.some(issue => issue.status === "FAILED")) {
      return "HIGH";
    }

    if (hasHighCreateCount) {
      return "MEDIUM";
    }

    return "LOW";
  }

  private buildSummary(plan: PlanItem[]): PlanSummary {
    const summary: PlanSummary = {
      area: { create: 0, exists: 0 },
      line: { create: 0, exists: 0 },
      machine: { create: 0, exists: 0 },
      operator: { create: 0, exists: 0 },
      totalCreate: 0,
      totalExists: 0
    };

    for (const item of plan) {
      const bucket = item?.type?.toLowerCase() as keyof Pick<PlanSummary, "area" | "line" | "machine" | "operator">;

      if (!summary[bucket]) {
        continue;
      }

      if (item.action === "CREATE") {
        summary[bucket].create += 1;
        summary.totalCreate += 1;
      } else if (item.action === "EXISTS") {
        summary[bucket].exists += 1;
        summary.totalExists += 1;
      }
    }

    return summary;
  }

  private buildAreaMap(foldersBeforeCreate: any[]): Map<string, string> {
    const areaMap = new Map<string, string>();

    for (const folder of foldersBeforeCreate) {
      if (folder.parentFolderUid === this.rootUid) {
        areaMap.set(folder.code, folder.uid);
      }
    }

    return areaMap;
  }

  private async createAreas(
    areaMap: Map<string, string>,
    areas: PlanItem[]
  ): Promise<void> {
    this.log(`Areas to create: ${areas.length}`);

    if (areas.length === 0) {
      return;
    }

    let created = 0;
    let skipped = 0;

    for (const item of areas) {
      // Check if area already exists
      if (areaMap.has(item.code)) {
        this.log(`Area already exists, skipping: ${item.code}`);
        skipped += 1;
        continue;
      }

      const uid = await createFolder(
        this.api,
        item.code,
        this.rootUid,
        item.name || item.code
      );

      areaMap.set(item.code, uid);
      created += 1;
      this.log(`Area created: ${item.code}`);
    }

    this.log(`Areas created: ${created}${skipped > 0 ? `, skipped: ${skipped}` : ""}`);
  }

  private async createLines(
    areaMap: Map<string, string>,
    lines: PlanItem[],
    foldersBeforeCreate: any[]
  ): Promise<void> {
    this.log(`Lines to create: ${lines.length}`);

    if (lines.length === 0) {
      return;
    }

    let created = 0;
    let skipped = 0;

    for (const item of lines) {
      const parentCode = item.parentCode || "";
      const parentUid = areaMap.get(parentCode);

      if (!parentUid) {
        throw new Error(
          `Cannot create line ${item.code}. Parent area not found: ${parentCode}`
        );
      }

      // Check if line already exists under parent area
      const lineExists = foldersBeforeCreate.some(
        folder => folder.code === item.code && folder.parentFolderUid === parentUid
      );

      if (lineExists) {
        this.log(`Line already exists, skipping: ${item.code}`);
        skipped += 1;
        continue;
      }

      await createFolder(
        this.api,
        item.code,
        parentUid,
        item.name || item.code
      );

      created += 1;
      this.log(`Line created: ${item.code}`);
    }

    this.log(`Lines created: ${created}${skipped > 0 ? `, skipped: ${skipped}` : ""}`);
  }

  private async executeResourceCreation(
    label: "Machines" | "Operators",
    itemsFromPlan: PlanItem[],
    existingCodeSet: Set<string>,
    targetFolderUid: string,
    elementConfigurationUid: string,
    apiEndpoint: string
  ): Promise<void> {
    const toCreate = itemsFromPlan.filter(
      item => !existingCodeSet.has(item.code)
    );

    this.log(`${label} to create: ${toCreate.length}`);

    if (toCreate.length === 0) {
      this.log(`${label} checked: ${itemsFromPlan.length}, no changes needed`);
      return;
    }

    let totalCreated = 0;

    await processInBatches(toCreate, 100, async (batch) => {
      const payload = batch.map(item => ({
        code: item.code,
        folderUid: targetFolderUid,
        elementConfigurationUid,
        description: {
          language: "en-US",
          text: item.name || item.code
        }
      }));

      try {
        const res = await this.api.post(apiEndpoint, payload);
        const createdInBatch = res.data?.entities?.length || batch.length;
        totalCreated += createdInBatch;
        this.log(`${label} created in batch: ${createdInBatch}`);
      } catch (err: any) {
        logApiError(`[ExecutionAgent] ${label} batch failed`, err);
        throw err;
      }
    });

    this.log(`${label} created: ${totalCreated}`);
  }

  private async getRuntimeContext(
    includeMachines: boolean,
    includeOperators: boolean
  ): Promise<RuntimeContext> {
    const hasMachineInventory =
      !includeMachines || this.runtimeContext?.machineSet instanceof Set;
    const hasOperatorInventory =
      !includeOperators || this.runtimeContext?.operatorSet instanceof Set;

    if (this.runtimeContext && hasMachineInventory && hasOperatorInventory) {
      return this.runtimeContext;
    }

    return await loadRuntimeContext(this.api, this.rootUid, {
      includeMachines,
      includeOperators
    });
  }

  private buildFailureMessage(): string {
    const failedIssues = this.issues
      .filter(issue => issue.status === "FAILED")
      .map(issue => `${issue.name}: ${issue.detail}`);

    return [
      "[ExecutionAgent] Plan validation failed",
      ...failedIssues
    ].join("\n");
  }
}

async function runExecutionAgent(
  api: any,
  rootUid: string,
  planPath: string,
  runtimeContext?: RuntimeContext
): Promise<void> {
  const executionAgent = new ExecutionAgent(api, rootUid, planPath, runtimeContext);
  await executionAgent.run();
}

// ---------- MAIN ----------
export async function executePlan(
  api: any,
  rootUid: string,
  planPath: string,
  runtimeContext?: RuntimeContext
): Promise<void> {
  if (rootUid && !rootUid.startsWith("Folder-")) {
    rootUid = `Folder-${rootUid}`;
  }

  await runExecutionAgent(api, rootUid, planPath, runtimeContext);
}
