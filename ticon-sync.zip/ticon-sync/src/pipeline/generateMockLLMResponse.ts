import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);

import { createTiconClient } from "../ticon/client";
import { loadRuntimeContext } from "../agents/runtimeContextAgent";
import { readRows } from "../excel/readRows";
import { extractUniques } from "../utils/extract";

type LLMPlanInput = {
	areas: string[];
	lines: { code: string; parentCode?: string }[];
	machines: string[];
	operators: string[];
	existingContext: {
		areas: string[];
		lines: string[];
		machines: string[];
		operators: string[];
	};
};

type MockLLMResponse = {
	items: Array<{
		type: "AREA" | "LINE" | "MACHINE" | "OPERATOR";
		code: string;
		parentCode?: string;
		action: "CREATE" | "EXISTS";
	}>;
};

function normalizeRootUid(rootUid: string): string {
	const trimmed = String(rootUid || "").trim();

	if (!trimmed) {
		throw new Error("Provide root UID");
	}

	if (trimmed.startsWith("Folder-")) {
		return trimmed;
	}

	return `Folder-${trimmed}`;
}

function buildMockResponse(input: LLMPlanInput): MockLLMResponse {
	return {
		items: [
			...input.areas.map((code) => ({
				type: "AREA" as const,
				code,
				action: input.existingContext.areas.includes(code)
					? "EXISTS" as const
					: "CREATE" as const
			})),
			...input.lines.map((line) => ({
				type: "LINE" as const,
				code: line.code,
				parentCode: line.parentCode,
				action: input.existingContext.lines.includes(line.code)
					? "EXISTS" as const
					: "CREATE" as const
			})),
			...input.machines.map((code) => ({
				type: "MACHINE" as const,
				code,
				action: input.existingContext.machines.includes(code)
					? "EXISTS" as const
					: "CREATE" as const
			})),
			...input.operators.map((code) => ({
				type: "OPERATOR" as const,
				code,
				action: input.existingContext.operators.includes(code)
					? "EXISTS" as const
					: "CREATE" as const
			}))
		]
	};
}

export async function generateMockLLMResponse(
	rootUid: string,
	excelFilePath = "TiConPEH API-TEST.xlsx"
): Promise<string> {
	const originalConsoleLog = console.log;

	try {
		console.log = () => undefined;

		const api = createTiconClient();
		const normalizedRootUid = normalizeRootUid(rootUid);
		const rows = readRows(excelFilePath);
		const uniques = extractUniques(rows);
		const runtimeContext = await loadRuntimeContext(api, normalizedRootUid, {
			includeMachines: true,
			includeOperators: true
		});

		// Build existing areas (AREA exists when folderKeySet contains: <areaCode>|<rootUid>)
		const existingAreas = Array.from(uniques.areas.keys()).filter((areaCode) =>
			runtimeContext.folderKeySet.has(`${areaCode}|${normalizedRootUid}`)
		);

		// Build existing lines (LINE exists when folderKeySet contains: <lineCode>|<parentAreaUid>)
		const existingLines = Array.from(uniques.lines.entries())
			.filter(([lineCode, lineData]) => {
				const parentAreaCode = lineData.areaCode;
				if (!parentAreaCode) return false;
				const parentAreaUid = runtimeContext.folderUidByKey.get(
					`${parentAreaCode}|${normalizedRootUid}`
				);
				if (!parentAreaUid) return false;
				return runtimeContext.folderKeySet.has(`${lineCode}|${parentAreaUid}`);
			})
			.map(([lineCode]) => lineCode);

		const input: LLMPlanInput = {
			areas: Array.from(uniques.areas.keys()),
			lines: Array.from(uniques.lines.entries()).map(([code, data]) => ({
				code,
				parentCode: data.areaCode
			})),
			machines: Array.from(uniques.machines),
			operators: Array.from(uniques.operators),
			existingContext: {
				areas: existingAreas,
				lines: existingLines,
				machines: Array.from(runtimeContext.machineSet),
				operators: Array.from(runtimeContext.operatorSet)
			}
		};
		const response = buildMockResponse(input);

		return JSON.stringify(response);
	} finally {
		console.log = originalConsoleLog;
	}
}

export async function printMockLLMResponse(
	rootUid: string,
	excelFilePath = "TiConPEH API-TEST.xlsx"
): Promise<void> {
	const json = await generateMockLLMResponse(rootUid, excelFilePath);
	process.stdout.write(json);
}

/**
 * Main entry point for the script
 * Generates and prints mock LLM response JSON to stdout
 */
async function main(): Promise<void> {
	const rootUid = process.argv[2];

	if (!rootUid) {
		console.error("[GenerateMockLLMResponse] Error: root UID required as first argument");
		console.error("[GenerateMockLLMResponse] Usage: node dist/pipeline/generateMockLLMResponse.js <rootUid> [excelFile]");
		process.exit(1);
	}

	try {
		const excelFile = process.argv[3] || "TiConPEH API-TEST.xlsx";
		const originalConsoleLog = console.log;

		// Silence console.log during data loading
		console.log = () => {};

		const api = createTiconClient();
		const normalizedRootUid = normalizeRootUid(rootUid);
		const rows = readRows(excelFile);
		const uniques = extractUniques(rows);
		const runtimeContext = await loadRuntimeContext(api, normalizedRootUid, {
			includeMachines: true,
			includeOperators: true
		});

		// Restore console.log before printing output
		console.log = originalConsoleLog;

		// Build existing areas (AREA exists when folderKeySet contains: <areaCode>|<rootUid>)
		const existingAreas = Array.from(uniques.areas.keys()).filter((areaCode) =>
			runtimeContext.folderKeySet.has(`${areaCode}|${normalizedRootUid}`)
		);

		// Build existing lines (LINE exists when folderKeySet contains: <lineCode>|<parentAreaUid>)
		const existingLines = Array.from(uniques.lines.entries())
			.filter(([lineCode, lineData]) => {
				const parentAreaCode = lineData.areaCode;
				if (!parentAreaCode) return false;
				const parentAreaUid = runtimeContext.folderUidByKey.get(
					`${parentAreaCode}|${normalizedRootUid}`
				);
				if (!parentAreaUid) return false;
				return runtimeContext.folderKeySet.has(`${lineCode}|${parentAreaUid}`);
			})
			.map(([lineCode]) => lineCode);

		const input: LLMPlanInput = {
			areas: Array.from(uniques.areas.keys()),
			lines: Array.from(uniques.lines.entries()).map(([code, data]) => ({
				code,
				parentCode: data.areaCode
			})),
			machines: Array.from(uniques.machines),
			operators: Array.from(uniques.operators),
			existingContext: {
				areas: existingAreas,
				lines: existingLines,
				machines: Array.from(runtimeContext.machineSet),
				operators: Array.from(runtimeContext.operatorSet)
			}
		};

		const response = buildMockResponse(input);
		console.log(JSON.stringify(response, null, 2));
	} catch (error: any) {
		console.error("[GenerateMockLLMResponse] Error:", error.message);
		process.exit(1);
	}
}

// Run main if this is the entry point
if (require.main === module) {
	main().catch((error) => {
		console.error("[GenerateMockLLMResponse] Fatal error:", error.message);
		process.exit(1);
	});
}
