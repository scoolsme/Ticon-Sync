import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);

import { writeFileSync } from "fs";
import { createTiconClient } from "../ticon/client";
import { runFullSyncRunner } from "./fullSyncRunner";
import { generateMockLLMResponse } from "./generateMockLLMResponse";

/**
 * Normalize a folder UID from numeric to "Folder-XXXXX" format
 */
function normalizeUid(uid: string): string {
	const trimmed = String(uid || "").trim();

	if (!trimmed) {
		throw new Error("Folder UID required");
	}

	if (trimmed.startsWith("Folder-")) {
		return trimmed;
	}

	// If numeric, prefix with Folder-
	if (/^\d+$/.test(trimmed)) {
		return `Folder-${trimmed}`;
	}

	return trimmed;
}

/**
 * get-uid <folderCode>
 * Search for folders by code and print their UIDs
 */
async function handleGetUid(folderCode: string): Promise<void> {
	if (!folderCode) {
		throw new Error("Folder code required. Usage: get-uid <folderCode>");
	}

	const API = {
		FOLDERS: "/ticon-web/services/data/folders"
	};

	const api = createTiconClient();

	const res = await api.get(API.FOLDERS, {
		params: {
			code: folderCode,
			"expand[description]": ""
		}
	});

	const entities = res.data.entities || [];

	console.log("  Search completed");
	console.log(`  Folders found: ${entities.length}`);

	if (entities.length === 0) {
		console.log("");
		console.log(`  No folder found for code: ${folderCode}`);
		return;
	}

	console.log("");

	for (let index = 0; index < entities.length; index++) {
		const folder = entities[index];
		const resultNumber = index + 1;

		console.log("  ----------------------------------------");
		console.log(`  [Result ${resultNumber}]`);
		console.log(`    Folder UID: ${folder.uid || ""}`);
		console.log(`    Path: ${folder.path || ""}`);
	}

	console.log("  ----------------------------------------");
	console.log("");
	console.log("  Copy the required Folder UID and paste it into Folder UID field.");
}

/**
 * plan <folderUid>
 * Run fullSyncRunner in plan-only mode
 */
async function handlePlan(folderUid: string): Promise<void> {
	if (!folderUid) {
		throw new Error("Folder UID required. Usage: plan <folderUid>");
	}

	const normalizedUid = normalizeUid(folderUid);

	// Enable plan-only mode
	process.env.FULLSYNC_PLAN_ONLY = "true";

	console.log(`[TiConAgentCli] Plan mode for Folder UID: ${normalizedUid}`);

	await runFullSyncRunner(normalizedUid);

	console.log("[TiConAgentCli] Plan completed");
}

/**
 * sync <folderUid>
 * Run fullSyncRunner in normal deterministic mode
 */
async function handleSync(folderUid: string): Promise<void> {
	if (!folderUid) {
		throw new Error("Folder UID required. Usage: sync <folderUid>");
	}

	const normalizedUid = normalizeUid(folderUid);

	// Ensure plan-only mode is disabled
	delete process.env.FULLSYNC_PLAN_ONLY;
	delete process.env.USE_LLM_PLAN;
	delete process.env.LLM_PLAN_RESPONSE_FILE;
	delete process.env.LLM_PLAN_RESPONSE;
	delete process.env.ALLOW_LLM_FALLBACK_EXECUTION;

	console.log(`[TiConAgentCli] Sync mode for Folder UID: ${normalizedUid}`);

	await runFullSyncRunner(normalizedUid);

	console.log("[TiConAgentCli] Sync completed");
}

/**
 * sync-llm <folderUid>
 * Run fullSyncRunner with LLM plan mode:
 * - generate mock LLM response
 * - set USE_LLM_PLAN=true
 * - set LLM_PLAN_RESPONSE_FILE
 * - clear other LLM flags
 * - execute full sync
 */
async function handleSyncLlm(folderUid: string): Promise<void> {
	if (!folderUid) {
		throw new Error("Folder UID required. Usage: sync-llm <folderUid>");
	}

	const normalizedUid = normalizeUid(folderUid);

	console.log(`[TiConAgentCli] LLM Sync mode for Folder UID: ${normalizedUid}`);

	// Generate mock LLM response
	console.log("[TiConAgentCli] Generating mock LLM response...");
	const mockLLMJson = await generateMockLLMResponse(normalizedUid);
	writeFileSync(".\\artifacts\\mock_llm_response.json", mockLLMJson);
	console.log("[TiConAgentCli] Mock LLM response written to .\\artifacts\\mock_llm_response.json");

	// Set LLM environment variables
	process.env.USE_LLM_PLAN = "true";
	process.env.LLM_PLAN_RESPONSE_FILE = ".\\artifacts\\mock_llm_response.json";

	// Clear other LLM flags
	delete process.env.FULLSYNC_PLAN_ONLY;
	delete process.env.LLM_PLAN_RESPONSE;
	delete process.env.ALLOW_LLM_FALLBACK_EXECUTION;

	console.log("[TiConAgentCli] Executing full sync with LLM plan...");

	await runFullSyncRunner(normalizedUid);

	console.log("[TiConAgentCli] LLM Sync completed");
}

/**
 * clear-llm-env
 * Remove/clear all LLM related environment variables
 */
async function handleClearLlmEnv(): Promise<void> {
	const llmEnvVars = [
		"USE_LLM_PLAN",
		"LLM_PLAN_RESPONSE_FILE",
		"LLM_PLAN_RESPONSE",
		"ALLOW_LLM_FALLBACK_EXECUTION",
		"FULLSYNC_PLAN_ONLY"
	];

	for (const envVar of llmEnvVars) {
		delete process.env[envVar];
	}

	console.log("[TiConAgentCli] Cleared LLM environment variables:");
	console.log(`  - ${llmEnvVars.join("\n  - ")}`);
}

/**
 * Print usage information
 */
function printUsage(): void {
	console.log("TiCon Sync Agent CLI");
	console.log("");
	console.log("Usage:");
	console.log("  get-uid <folderCode>        Search for folders by code and print UIDs");
	console.log("  plan <folderUid>            Generate plan only (no execution)");
	console.log("  sync <folderUid>            Execute sync with deterministic planner");
	console.log("  sync-llm <folderUid>        Execute sync with LLM planner");
	console.log("  clear-llm-env               Clear all LLM environment variables");
	console.log("");
	console.log("Examples:");
	console.log("  node dist/pipeline/ticonAgentCli.js get-uid PEH");
	console.log("  node dist/pipeline/ticonAgentCli.js plan Folder-15181");
	console.log("  node dist/pipeline/ticonAgentCli.js plan 15181");
	console.log("  node dist/pipeline/ticonAgentCli.js sync 15181");
	console.log("  node dist/pipeline/ticonAgentCli.js sync-llm 15181");
	console.log("  node dist/pipeline/ticonAgentCli.js clear-llm-env");
}

/**
 * Main entry point
 */
async function main(): Promise<void> {
	// Check for help flags first
	if (process.argv.includes("--help") || process.argv.includes("-h") || process.argv.includes("help")) {
		printUsage();
		return;
	}

	const command = process.argv[2];
	const arg1 = process.argv[3];

	try {
		switch (command) {
			case "get-uid":
				await handleGetUid(arg1);
				break;

			case "plan":
				await handlePlan(arg1);
				break;

			case "sync":
				await handleSync(arg1);
				break;

			case "sync-llm":
				await handleSyncLlm(arg1);
				break;

			case "clear-llm-env":
				await handleClearLlmEnv();
				break;

			default:
				if (command) {
					console.error(`[TiConAgentCli] Unknown command: ${command}`);
				} else {
					console.error("[TiConAgentCli] No command provided");
				}
				console.error("");
				printUsage();
				process.exit(1);
		}
	} catch (error: any) {
		const details = error.response?.data
			? JSON.stringify(error.response.data)
			: error.message;

		console.error(`[TiConAgentCli] Error: ${details}`);
		process.exit(1);
	}
}

main().catch(err => {
	console.error(`[TiConAgentCli] Fatal error: ${err.message}`);
	process.exit(1);
});
