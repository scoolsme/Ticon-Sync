type PlanItem = {
  type: string;
  code: string;
  action: string;
  description?: string;
};

export function buildPlan(uniques: any): PlanItem[] {
  const plan: PlanItem[] = [];

  // Areas
  for (const [code, name] of uniques.areas.entries()) {
    plan.push({
      type: "AREA",
      code,
      action: "CREATE",
      description: name
    });
  }

  // Lines
  for (const [code, name] of uniques.lines.entries()) {
    plan.push({
      type: "LINE",
      code,
      action: "CREATE",
      description: name
    });
  }

  // Operators
  for (const code of uniques.operators) {
    plan.push({
      type: "OPERATOR",
      code,
      action: "CREATE"
    });
  }

  // Machines
  for (const code of uniques.machines) {
    plan.push({
      type: "MACHINE",
      code,
      action: "CREATE"
    });
  }

  return plan;
}