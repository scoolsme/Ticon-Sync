import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);

import { createTiconClient } from "../ticon/client";

const API = {
  FOLDERS: "/ticon-web/services/data/folders"
};

function getFolderCode(): string {
  const folderCode = process.argv[2] || "";
  return folderCode.trim();
}

function printSeparator(): void {
  console.log("  ----------------------------------------");
}

async function run(): Promise<void> {
  const folderCode = getFolderCode();

  if (!folderCode) {
    throw new Error("Please provide Folder Code.");
  }

  const api = createTiconClient();

  const res = await api.get(API.FOLDERS, {
    params: {
      code: folderCode,
      "expand[description]": ""
    }
  });

  const entities = res.data.entities || [];

  console.log("  Search completed");
  console.log(`  Folders found: ${entities.length}`);

  if (entities.length === 0) {
    console.log("");
    console.log(`  No folder found for code: ${folderCode}`);
    return;
  }

  console.log("");

  for (let index = 0; index < entities.length; index++) {
    const folder = entities[index];
    const resultNumber = index + 1;

    printSeparator();
    console.log(`  [Result ${resultNumber}]`);
    console.log(`    Folder UID: ${folder.uid || ""}`);
    console.log(`    Path: ${folder.path || ""}`);
  }

  printSeparator();
  console.log("");
  console.log("  Copy the required Folder UID and paste it into Folder UID field.");
}

run().catch(err => {
  const details = err.response?.data
    ? JSON.stringify(err.response.data)
    : err.message;

  console.error(`  Folder search failed: ${details}`);
  process.exit(1);
});
