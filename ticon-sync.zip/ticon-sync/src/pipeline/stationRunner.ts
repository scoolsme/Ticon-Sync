import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);

import { readFileSync, existsSync } from "fs";
import { createTiconClient } from "../ticon/client";
import { readRows, Row } from "../excel/readRows";
import {
  loadRuntimeContext,
  fetchRuntimeEntities
} from "../agents/runtimeContextAgent";
import type { RuntimeContext } from "../agents/runtimeContextAgent";
import { loadMachineInventory, loadOperatorInventory } from "../agents/inventoryAgent";

// ---------- CONFIG ----------
const CONFIG = {
  STATION: "ElementClassConfiguration-100033"
};

const API = {
  FOLDERS: "/ticon-web/services/data/folders",
  STATIONS: "/ticon-web/services/data/resource-station-elements",
  MACHINES: "/ticon-web/services/data/resource-machine-elements",
  OPERATORS: "/ticon-web/services/data/resource-operator-elements"
};

type ResourceType = "ResourceMachine" | "ResourceOperator";

type MachineOrOperatorReference = {
  row?: {
    elementUid?: string;
    factor?: string;
    orderNumber?: number;
    typeEnum?: ResourceType;
    rowType?: "MACHINEOROPERATORREFERENCE";
  };
  identifier?: string;
};

type StationGroup = {
  workcenterCode: string;
  workstationName: string;
  operatorCode: string;
  machineCodes: string[];
};

type ExistingStation = {
  uid: string;
  code: string;
  folderUid: string;
  machinesOrOperators?: MachineOrOperatorReference[];
};

// ---------- BATCH ----------
async function processInBatches<T>(
  items: T[],
  batchSize: number,
  handler: (batch: T[], batchIndex: number) => Promise<void>
): Promise<void> {
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchIndex = Math.floor(i / batchSize) + 1;
    await handler(batch, batchIndex);
  }
}

// ---------- GROUP ROWS BY WORKCENTER ----------
function groupRowsByWorkcenter(rows: Row[]): StationGroup[] {
  const grouped = new Map<string, Row[]>();

  for (const row of rows) {
    if (!row.workcenterCode) {
      continue;
    }

    const stationRows = grouped.get(row.workcenterCode) || [];
    stationRows.push(row);
    grouped.set(row.workcenterCode, stationRows);
  }

  const stationGroups: StationGroup[] = [];

  for (const [workcenterCode, stationRows] of grouped.entries()) {
    const firstRow = stationRows[0];
    const machineCodeSet = new Set<string>();

    for (const row of stationRows) {
      if (row.machineCode) {
        machineCodeSet.add(row.machineCode);
      }
    }

    const operatorCodes = Array.from(
      new Set(
        stationRows
          .map(row => row.operatorCode)
          .filter((code): code is string => Boolean(code))
      )
    );

    if (operatorCodes.length > 1) {
      console.log(
        `Warning: Multiple operators found for ${workcenterCode}. Using first operator: ${operatorCodes[0]}`
      );
    }

    stationGroups.push({
      workcenterCode,
      workstationName: firstRow.workstationName || workcenterCode,
      operatorCode: operatorCodes[0] || "",
      machineCodes: Array.from(machineCodeSet)
    });
  }

  return stationGroups;
}

// ---------- BUILD EXPECTED REFERENCES FROM EXCEL ----------
function buildExpectedReferences(
  station: StationGroup,
  machineMap: Map<string, string>,
  operatorMap: Map<string, string>
): MachineOrOperatorReference[] {
  const references: MachineOrOperatorReference[] = [];
  const addedKeys = new Set<string>();
  let orderNumber = 1;

  for (const machineCode of station.machineCodes) {
    const machineUid = machineMap.get(machineCode);

    if (!machineUid) {
      console.log(
        `Warning: Machine not found in MA folder: ${machineCode} for workstation ${station.workcenterCode}`
      );
      continue;
    }

    const key = `ResourceMachine|${machineUid}`;

    if (addedKeys.has(key)) {
      continue;
    }

    references.push({
      row: {
        elementUid: machineUid,
        factor: "1",
        orderNumber,
        typeEnum: "ResourceMachine",
        rowType: "MACHINEOROPERATORREFERENCE"
      }
    });

    addedKeys.add(key);
    orderNumber++;
  }

  if (station.operatorCode) {
    const operatorUid = operatorMap.get(station.operatorCode);

    if (!operatorUid) {
      console.log(
        `Warning: Operator not found in OP folder: ${station.operatorCode} for workstation ${station.workcenterCode}`
      );
    } else {
      const key = `ResourceOperator|${operatorUid}`;

      if (!addedKeys.has(key)) {
        references.push({
          row: {
            elementUid: operatorUid,
            factor: "1",
            orderNumber,
            typeEnum: "ResourceOperator",
            rowType: "MACHINEOROPERATORREFERENCE"
          }
        });

        addedKeys.add(key);
      }
    }
  }

  return references;
}

// ---------- REFERENCE COMPARISON ----------
function buildReferenceKeys(
  refs: MachineOrOperatorReference[] | undefined
): string[] {
  const keys: string[] = [];

  if (!refs) {
    return keys;
  }

  for (const ref of refs) {
    if (!ref.row || !ref.row.elementUid || !ref.row.typeEnum) {
      continue;
    }

    keys.push(`${ref.row.typeEnum}|${ref.row.elementUid}`);
  }

  return keys;
}

function areReferencesSame(
  existingRefs: MachineOrOperatorReference[] | undefined,
  expectedRefs: MachineOrOperatorReference[]
): boolean {
  if (!existingRefs) {
    return expectedRefs.length === 0;
  }

  const existingKeys = buildReferenceKeys(existingRefs);
  const expectedKeys = buildReferenceKeys(expectedRefs);

  // TiCon sometimes returns full reference details with row.elementUid and row.typeEnum.
  // If full reference details are available, compare exactly by UID and resource type.
  if (existingKeys.length > 0) {
    if (existingKeys.length !== expectedKeys.length) {
      return false;
    }

    const existingSet = new Set(existingKeys);
    const expectedSet = new Set(expectedKeys);

    if (existingSet.size !== existingKeys.length) {
      return false;
    }

    if (expectedSet.size !== expectedKeys.length) {
      return false;
    }

    if (existingSet.size !== expectedSet.size) {
      return false;
    }

    for (const key of expectedSet) {
      if (!existingSet.has(key)) {
        return false;
      }
    }

    return true;
  }

  // Fallback:
  // TiCon may return only relationship identifiers like { identifier: "4859597" }.
  // In that response shape, exact UID comparison is not possible.
  // Compare count only to avoid correcting every station on every run.
  return existingRefs.length === expectedRefs.length;
}

// ---------- UPDATE EXISTING STATIONS ----------
async function updateStationBatch(api: any, payload: any[]): Promise<any> {
  try {
    return await api.put(API.STATIONS, payload);
  } catch (putErr: any) {
    const status = putErr.response?.status;

    if (status === 404 || status === 405 || status === 501) {
      return await api.patch(API.STATIONS, payload);
    }

    throw putErr;
  }
}

// ---------- TRY LOAD FROM ARTIFACT ----------
interface RuntimeContextArtifact {
  rootUid: string;
  pehFolderUid: string;
  maFolderUid: string;
  opFolderUid: string;
  pehPath: string;
  machinePath: string;
  operatorPath: string;
  createdAt: string;
}

async function tryLoadFromArtifact(
  api: any,
  rootUid: string
): Promise<{
  pehUid: string;
  pehPath: string;
  operatorPath: string;
  machinePath: string;
  operatorMap: Map<string, string>;
  machineMap: Map<string, string>;
} | null> {
  const artifactPath = `artifacts/runtimeContext_${rootUid}.json`;
  const ARTIFACT_TTL_MS = 10 * 60 * 1000; // 10 minutes

  if (!existsSync(artifactPath)) {
    return null;
  }

  try {
    const artifact: RuntimeContextArtifact = JSON.parse(
      readFileSync(artifactPath, "utf-8")
    );

    const createdAt = new Date(artifact.createdAt).getTime();
    const now = Date.now();

    if (now - createdAt >= ARTIFACT_TTL_MS) {
      console.log("[StationRunnerAgent] Artifact expired, reloading from TiCon");
      return null;
    }

    console.log("[StationRunnerAgent] Using runtime context from artifact");

    const operators = await loadOperatorInventory(api, artifact.operatorPath);
    const machines = await loadMachineInventory(api, artifact.machinePath);

    const operatorMap = new Map<string, string>();
    const machineMap = new Map<string, string>();

    for (const operator of operators) {
      operatorMap.set(operator.code, operator.uid);
    }

    for (const machine of machines) {
      machineMap.set(machine.code, machine.uid);
    }

    return {
      pehUid: artifact.pehFolderUid,
      pehPath: artifact.pehPath,
      operatorPath: artifact.operatorPath,
      machinePath: artifact.machinePath,
      operatorMap,
      machineMap
    };
  } catch (err: any) {
    console.log(`[StationRunnerAgent] Failed to load artifact: ${err.message}, falling back to full context load`);
    return null;
  }
}

class StationRunnerAgent {
  private readonly api: any;

  private readonly stationGroups: StationGroup[];

  private pehUid = "";

  private pehPath = "";

  private operatorPath = "";

  private machinePath = "";

  private operatorMap = new Map<string, string>();

  private machineMap = new Map<string, string>();

  private existingStationMap = new Map<string, ExistingStation>();

  private created = 0;

  private updated = 0;

  private skipped = 0;

  private correctionRequired = 0;

  constructor(
    private rootUid: string,
    api?: any,
    private readonly runtimeContext?: RuntimeContext
  ) {
    this.api = api || createTiconClient();
    const sourceRows: Row[] = readRows("TiConPEH API-TEST.xlsx");
    this.stationGroups = groupRowsByWorkcenter(sourceRows);
  }

  public async run(): Promise<void> {
    this.log("Station Runner Started");
    this.log(`Root UID: ${this.rootUid}`);
    this.log(`Stations from Excel: ${this.stationGroups.length}`);

    await this.resolveTemplate();
    this.validateStationReferences();
    await this.loadExistingStations();
    await this.processStationBatches();
    this.logSummary();
    this.log("Station Runner Completed");
  }

  private async resolveTemplate(): Promise<void> {
    let pehUid: string;
    let pehPath: string;
    let operatorPath: string;
    let machinePath: string;
    let operatorMap: Map<string, string>;
    let machineMap: Map<string, string>;

    if (this.runtimeContext) {
      this.log("Using provided runtime context");

      pehUid = this.runtimeContext.pehFolder.uid;
      pehPath = this.runtimeContext.pehPath;
      operatorPath = this.runtimeContext.operatorPath;
      machinePath = this.runtimeContext.machinePath;

      operatorMap = new Map<string, string>();
      machineMap = new Map<string, string>();

      for (const operator of this.runtimeContext.operators) {
        operatorMap.set(operator.code, operator.uid);
      }

      for (const machine of this.runtimeContext.machines) {
        machineMap.set(machine.code, machine.uid);
      }
    } else {
      // Try to load from artifact first
      const artifactContext = await tryLoadFromArtifact(this.api, this.rootUid);

      if (artifactContext) {
        pehUid = artifactContext.pehUid;
        pehPath = artifactContext.pehPath;
        operatorPath = artifactContext.operatorPath;
        machinePath = artifactContext.machinePath;
        operatorMap = artifactContext.operatorMap;
        machineMap = artifactContext.machineMap;
      } else {
        // Fallback to full context load
        let context: Awaited<ReturnType<typeof loadRuntimeContext>>;

        try {
          context = await loadRuntimeContext(this.api, this.rootUid, {
            includeMachines: true,
            includeOperators: true
          });
        } catch (err: any) {
          const message = String(err?.message || "");

          if (message.includes("PEH not found")) {
            throw new Error("PEH not found. Copy WORKCENTER [PEH] from template first.");
          }

          throw err;
        }

        pehUid = context.pehFolder.uid;
        pehPath = context.pehPath;
        operatorPath = context.operatorPath;
        machinePath = context.machinePath;

        operatorMap = new Map<string, string>();
        machineMap = new Map<string, string>();

        for (const operator of context.operators) {
          operatorMap.set(operator.code, operator.uid);
        }

        for (const machine of context.machines) {
          machineMap.set(machine.code, machine.uid);
        }
      }
    }

    this.pehUid = pehUid;
    this.pehPath = pehPath;
    this.operatorPath = operatorPath;
    this.machinePath = machinePath;
    this.operatorMap = operatorMap;
    this.machineMap = machineMap;

    this.log(`PEH Path: ${this.pehPath}`);
    this.log(`Operator Path: ${this.operatorPath}`);
    this.log(`Machine Path: ${this.machinePath}`);

    this.log(`Machines loaded: ${this.machineMap.size}`);
    this.log(`Operators loaded: ${this.operatorMap.size}`);
  }

  private validateStationReferences(): void {
    const missingMessages: string[] = [];

    for (const station of this.stationGroups) {
      const missingMachineCodes = station.machineCodes.filter(
        machineCode => !this.machineMap.has(machineCode)
      );

      if (missingMachineCodes.length > 0) {
        missingMessages.push(
          `Missing machine(s) in MA folder for ${station.workcenterCode}: ${missingMachineCodes.join(", ")}`
        );
      }

      if (station.operatorCode && !this.operatorMap.has(station.operatorCode)) {
        missingMessages.push(
          `Missing operator in OP folder for ${station.workcenterCode}: ${station.operatorCode}`
        );
      }
    }

    if (missingMessages.length > 0) {
      throw new Error(`Station reference validation failed: ${missingMessages.join(" | ")}`);
    }
  }

  private async loadExistingStations(): Promise<void> {
    const existingStations = await fetchRuntimeEntities(
      this.api,
      `${API.STATIONS}?folderpath=${encodeURIComponent(this.pehPath)}&expand%5BmachinesOrOperators%5D=`,
      {},
      "existing stations"
    );

    for (const station of existingStations) {
      this.existingStationMap.set(station.code, station);
    }

    this.log(`Existing stations in PEH: ${this.existingStationMap.size}`);
  }

  private async processStationBatches(): Promise<void> {
    await processInBatches(this.stationGroups, 30, async (batch, batchIndex) => {
      const createPayload: any[] = [];
      const updatePayload: any[] = [];

      for (const station of batch) {
        const expectedRefs = buildExpectedReferences(
          station,
          this.machineMap,
          this.operatorMap
        );

        const existingStation = this.existingStationMap.get(station.workcenterCode);

        if (!existingStation) {
          createPayload.push({
            Code: station.workcenterCode,
            Description: {
              language: "en-US",
              text: station.workstationName || station.workcenterCode
            },
            folderUid: this.pehUid,
            elementConfigurationUid: CONFIG.STATION,
            machinesOrOperators: expectedRefs
          });

          continue;
        }

        const isSame = areReferencesSame(
          existingStation.machinesOrOperators,
          expectedRefs
        );

        if (isSame) {
          this.skipped++;
          continue;
        }

        updatePayload.push({
          uid: existingStation.uid,
          Code: station.workcenterCode,
          Description: {
            language: "en-US",
            text: station.workstationName || station.workcenterCode
          },
          folderUid: this.pehUid,
          elementConfigurationUid: CONFIG.STATION,
          machinesOrOperators: expectedRefs
        });

        this.correctionRequired++;
      }

      if (createPayload.length > 0 || updatePayload.length > 0) {
        console.log(`[StationRunnerAgent] Processing batch ${batchIndex}`);
      }

      if (createPayload.length > 0) {
        try {
          const res = await this.api.post(API.STATIONS, createPayload);
          const count = res.data.entities?.length || 0;
          this.created += count;
          this.log(`Stations created in batch: ${count}`);
        } catch (err: any) {
          this.log("Create batch failed");
          this.log(err.response?.data || err.message);
          throw err;
        }
      }

      if (updatePayload.length > 0) {
        try {
          const res = await updateStationBatch(this.api, updatePayload);
          const count = res.data.entities?.length || updatePayload.length;
          this.updated += count;
          this.log(`Stations corrected in batch: ${count}`);
        } catch (err: any) {
          this.log("Update batch failed");
          this.log(err.response?.data || err.message);
          throw err;
        }
      }
    });
  }

  private logSummary(): void {
    if (this.created === 0 && this.updated === 0 && this.correctionRequired === 0) {
      this.log(`Stations checked: ${this.skipped}, no changes needed`);
      return;
    }

    this.log(`Stations checked: ${this.stationGroups.length}`);
    this.log(`Stations created: ${this.created}`);
    this.log(`Stations updated: ${this.updated}`);
    this.log(`Stations needing update: ${this.correctionRequired}`);
  }

  private log(message: string): void {
    console.log(`[StationRunnerAgent] ${message}`);
  }
}

// ---------- MAIN ----------
export async function runStationRunner(
  rootUid: string,
  options?: {
    api?: any;
    runtimeContext?: RuntimeContext;
  }
): Promise<void> {
  if (!rootUid) {
    console.error("    Provide root UID");
    process.exit(1);
  }

  if (!rootUid.startsWith("Folder-")) {
    rootUid = `Folder-${rootUid}`;
  }

  const agent = new StationRunnerAgent(rootUid, options?.api, options?.runtimeContext);
  await agent.run();
}

// ---------- RUN ----------
if (require.main === module) {
  runStationRunner(process.argv[2]).catch(err => {
    console.error("Station Runner failed:", err.response?.data || err.message);
    process.exit(1);
  });
}
