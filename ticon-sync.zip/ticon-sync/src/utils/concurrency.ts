export async function asyncPool<T, R>(
  poolLimit: number,
  items: T[],
  iteratorFn: (item: T) => Promise<R>
): Promise<R[]> {

  const results: R[] = [];
  const executing: Promise<void>[] = [];

  for (const item of items) {
    const p = Promise.resolve().then(async () => {
      const result = await iteratorFn(item);
      results.push(result);
    });

    if (poolLimit <= items.length) {
      executing.push(p);

      if (executing.length >= poolLimit) {
        await Promise.race(executing);
        executing.splice(executing.findIndex(e => e === p), 1);
      }
    }
  }

  await Promise.all(executing);
  return results;
}
