import { Row } from "../excel/readRows";

export function extractUniques(rows: Row[]) {

  const areas = new Map<string, string>();
  const lines = new Map<string, { name: string; areaCode: string }>();
  const operators = new Set<string>();
  const machines = new Set<string>();

  for (const r of rows) {

    if (r.areaCode) {
      areas.set(r.areaCode, r.areaName);
    }

    if (r.lineCode) {
      lines.set(r.lineCode, {
        name: r.lineName,
        areaCode: r.areaCode
      });
    }

    if (r.operatorCode) {
      operators.add(r.operatorCode.trim());
    }

    if (r.machineCode) {
      machines.add(r.machineCode.trim());
    }
  }

  return { areas, lines, operators, machines };
}