import "dotenv/config";
import { createTiconClient } from "./ticon/client";
import { readRows } from "./excel/readRows";
import { extractUniques } from "./utils/extract";
import { buildSmartPlan } from "./pipeline/smartPlan";
import { executePlan } from "./pipeline/executor";
import { resolveTemplateStructure } from "./agents/templateStructureAgent";
import { writeFileSync } from "fs";

// ---------- ARG PARSER ----------
const args = process.argv.slice(2);

let rootUid = "";
let execute = false;

for (let i = 0; i < args.length; i++) {
  if (args[i] === "--uid") rootUid = args[i + 1];
  if (args[i] === "--execute") execute = args[i + 1] === "true";
}

if (!rootUid) {
  console.error("Please provide --uid");
  process.exit(1);
}

// ---------- FETCH ALL ----------
async function fetchAll(api: any, url: string) {
  const pageSize = 500;
  let skip = 0;
  let all: any[] = [];

  while (true) {
    const res = await api.get(url, { params: { pageSize, skip } });
    const data = res.data.entities;
    all = all.concat(data);

    if (data.length < pageSize) break;
    skip += pageSize;
  }

  return all;
}

// ---------- VALIDATE TEMPLATE STRUCTURE ----------
async function validateBaseFolders(api: any, normalizedRootUid: string) {

  console.log("    Validating template hierarchy...");

  const folders = await fetchAll(
    api,
    "/ticon-web/services/data/folders"
  );

  resolveTemplateStructure(folders, normalizedRootUid);

  console.log("    Template structure OK");
}

// ---------- MAIN ----------
async function main() {

  console.log("    TiCon CLI started");
  console.log("    Root UID:", rootUid);

  const rows = readRows("TiConPEH API-TEST.xlsx");

  const uniques = extractUniques(rows);

  const api = createTiconClient();

  if (execute) {
    // Template validation is handled by RuntimeContextAgent during planning
  }

  const smartPlan = await buildSmartPlan(
    api,
    {
      areas: uniques.areas,
      lines: uniques.lines,
      machines: Array.from(uniques.machines),
      operators: Array.from(uniques.operators),
    },
    rootUid
  );

  writeFileSync(
    "artifacts/smartPlan.json",
    JSON.stringify(smartPlan, null, 2)
  );

  if (execute) {

    console.log("    Execution started");

    await executePlan(
      api,
      rootUid,
      "artifacts/smartPlan.json"
    );
  }

  console.log("    Done");
}

// ---------- RUN ----------
main().catch(err => {
  console.error("Error:", err.response?.data || err.message);
  process.exit(1);
});



