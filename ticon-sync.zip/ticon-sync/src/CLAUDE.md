# TiCon Sync Project Rules

This project syncs Excel-based manufacturing master data into TiCon using REST APIs.

The system uses a rule-driven agentic architecture.

The Markdown rules in this file define how the agents must behave. The TypeScript code must enforce these rules, validate all decisions, and perform all REST API calls safely.

The AI/LLM layer may read this file to generate plans, explanations, validations, and recommendations. The AI/LLM layer must not directly modify TiCon data.

---

## Source of Truth

The Excel file is the source of truth.

The application must sync:

- production areas
- production lines
- machines
- operators
- stations
- station machine/operator links

The Excel file defines the intended manufacturing structure.

If TiCon and Excel differ:

- Excel is treated as desired state.
- TiCon is treated as current state.
- The system must create missing allowed objects.
- The system must not delete TiCon objects unless a future rule explicitly allows deletion.

---

## UID Rules

If the user provides a numeric folder UID such as:

```text
15129
```

The application must normalize it to:

```text
Folder-15129
```

If the user provides:

```text
Folder-15129
```

The application must keep it unchanged.

The selected Folder UID is the root folder for the sync operation.

---

## Template Folder Rules

The following folders are copied from template manually:

- PEH
- MA
- OP
- PRODUCT VARIANT

The application must not create:

- PEH
- MA
- OP
- PRODUCT VARIANT

The application must validate that required template folders exist before planning or execution.

Required template structure:

```text
Root Folder
  PEH
    MA
    OP
```

If PEH is missing, the sync must stop.

If MA is missing under PEH, the sync must stop.

If OP is missing under PEH, the sync must stop.

---

## Allowed Creation Rules

The application can create:

- production area folders
- production line folders
- machine elements
- operator elements
- station elements
- station machine/operator links

The application must only create objects that are missing from TiCon and present in the Excel source.

The application must not create duplicates.

The application must be idempotent.

Running the same sync twice should result in:

```text
No changes needed
```

on the second run.

---

## RuntimeContextAgent Rules

The RuntimeContextAgent is responsible for building the current TiCon runtime context.

The RuntimeContextAgent must:

- normalize the root Folder UID
- load folder inventory
- resolve PEH, MA, and OP
- build PEH path
- build machine path
- build operator path
- load machine inventory when needed
- load operator inventory when needed
- expose reusable runtime context to planning, execution, and station sync

The RuntimeContextAgent must not create, update, or delete TiCon objects.

The RuntimeContextAgent may write a lightweight runtime context artifact for reuse.

The RuntimeContextAgent must prefer in-memory sharing when running inside FullSyncAgent.

If runtime context cannot be resolved, the sync must stop before any write operation.

---

## Inventory Rules

The inventory layer is responsible for reading current TiCon state.

Inventory loading may include:

- folders
- machines
- operators
- existing stations

Inventory reads must be GET-only.

Inventory reads may use retry logic for transient network failures.

Retry is allowed for:

- ECONNRESET
- ETIMEDOUT
- ECONNABORTED
- EAI_AGAIN
- ENOTFOUND
- ECONNREFUSED
- HTTP 502
- HTTP 503
- HTTP 504

Retry must not be used for authentication or authorization errors such as:

- HTTP 401
- HTTP 403

Inventory loading must not perform write operations.

---

## TemplateStructureAgent Rules

The TemplateStructureAgent is responsible for validating the manually copied template structure.

The TemplateStructureAgent must:

- find PEH under the selected root folder
- find MA under PEH
- find OP under PEH
- build PEH path
- build machine path
- build operator path

The TemplateStructureAgent must fail if PEH, MA, or OP is missing.

The TemplateStructureAgent must not create PEH, MA, or OP.

The TemplateStructureAgent must not call write APIs.

---

## HierarchyPlanningAgent Rules

The HierarchyPlanningAgent is responsible for deciding what should be created and what already exists.

The HierarchyPlanningAgent must compare:

```text
Excel desired state
vs
TiCon current state
```

The HierarchyPlanningAgent must generate a SmartPlan.

Each SmartPlan item must have:

```json
{
  "type": "AREA | LINE | MACHINE | OPERATOR",
  "code": "string",
  "parentCode": "string when required",
  "action": "CREATE | EXISTS"
}
```

Planning rules:

- If an area exists under the root folder, mark it as EXISTS.
- If an area does not exist under the root folder, mark it as CREATE.
- If a line exists under its parent area, mark it as EXISTS.
- If a line does not exist under its parent area, mark it as CREATE.
- If a machine exists under PEH/MA, mark it as EXISTS.
- If a machine does not exist under PEH/MA, mark it as CREATE.
- If an operator exists under PEH/OP, mark it as EXISTS.
- If an operator does not exist under PEH/OP, mark it as CREATE.

The HierarchyPlanningAgent must not perform TiCon write operations.

The HierarchyPlanningAgent may assign a risk level internally, but GUI output should not show risk wording to business users unless explicitly requested.

The HierarchyPlanningAgent must produce deterministic output.

---

## LLMPlanAgent Rules

The LLMPlanAgent may be used to generate a plan from instructions.

The LLMPlanAgent must read this rules file as its instruction source.

The LLMPlanAgent must only generate a plan.

The LLMPlanAgent must not call TiCon APIs.

The LLMPlanAgent must not create, update, or delete TiCon data.

The LLMPlanAgent output must be structured JSON.

The LLMPlanAgent output must be validated by code before execution.

If LLM output is invalid, incomplete, or unsafe:

- reject the LLM plan
- fall back to the deterministic HierarchyPlanningAgent

The LLMPlanAgent must not override actual TiCon state.

If the LLM says an item should be CREATE but TiCon already contains it, code must force EXISTS.

If the LLM says an item should be EXISTS but TiCon does not contain it, code must force CREATE.

The LLM is allowed to reason. The code is responsible for truth and execution.

---

## ExecutionAgent Rules

The ExecutionAgent is responsible for safe execution of an approved SmartPlan.

The ExecutionAgent must:

- load SmartPlan
- validate SmartPlan structure
- reject invalid plans
- summarize CREATE and EXISTS actions
- create areas before lines
- create lines before resource-dependent station sync
- create machines in batches
- create operators in batches
- avoid duplicate creation
- stop on unrecoverable errors

The ExecutionAgent must validate:

- type is one of AREA, LINE, MACHINE, OPERATOR
- action is one of CREATE, EXISTS
- LINE items have parentCode
- parent area exists before line creation
- required PEH/MA/OP structure exists before resource creation

Execution order:

```text
1. Validate plan
2. Create AREA folders
3. Create LINE folders
4. Create MACHINE elements
5. Create OPERATOR elements
```

The ExecutionAgent must not create:

- PEH
- MA
- OP
- PRODUCT VARIANT

The ExecutionAgent must create only items marked CREATE.

The ExecutionAgent must skip items marked EXISTS.

The ExecutionAgent must use deterministic API payloads.

The ExecutionAgent must not allow LLM-generated payloads to directly reach TiCon APIs.

---

## Area and Line Rules

Areas are folder objects under the selected root folder.

Lines are folder objects under their parent area.

Area creation rules:

- create area only if missing
- parent folder must be selected root folder
- name must use Excel name if available
- otherwise name must use code

Line creation rules:

- create line only if missing
- parent area must exist
- parentCode must resolve to area UID
- name must use Excel name if available
- otherwise name must use code

If a line parent area cannot be resolved, stop execution.

The error must clearly identify:

- line code
- missing parent area code

---

## Machine Rules

Machines are resource machine elements under PEH/MA.

Machine creation rules:

- create machine only if present in Excel
- create machine only if missing in TiCon PEH/MA
- do not duplicate existing machine codes
- batch machine creation
- keep batch size controlled
- log progress per batch

Machine payload must include:

- code
- folder UID of MA
- machine element configuration UID
- English description

---

## Operator Rules

Operators are resource operator elements under PEH/OP.

Operator creation rules:

- create operator only if present in Excel
- create operator only if missing in TiCon PEH/OP
- do not duplicate existing operator codes
- batch operator creation
- keep batch size controlled
- log progress per batch

Operator payload must include:

- code
- folder UID of OP
- operator element configuration UID
- English description

---

## Workstation and Station Rules

Stations are created from Excel workstation data.

One workstation can have multiple machines.

One workstation can have only one operator.

If multiple operators are found for one workstation:

- warn in detailed logs
- use the first operator
- continue execution

StationRunnerAgent must:

- read station data from Excel
- use PEH path from runtime context
- use machine inventory from runtime context when provided
- use operator inventory from runtime context when provided
- load existing stations from TiCon
- create missing stations
- update stations only if update logic is enabled
- skip stations that already match desired state

If all Excel stations already exist and no update is required:

```text
Stations checked: X, no changes needed
```

StationRunnerAgent must be idempotent.

---

## FullSyncAgent Rules

The FullSyncAgent is the main orchestrator for GUI execution.

The FullSyncAgent must run the full sync in one Node.js process when possible.

The FullSyncAgent must:

```text
1. read Excel input
2. load RuntimeContext once
3. build SmartPlan
4. execute SmartPlan
5. refresh RuntimeContext only if machine/operator creation occurred
6. run StationRunnerAgent
```

The FullSyncAgent must share RuntimeContext in memory with:

- HierarchyPlanningAgent
- ExecutionAgent
- StationRunnerAgent

The FullSyncAgent must reload RuntimeContext before StationRunnerAgent only when newly created machines or operators may be needed by stations.

The FullSyncAgent must stop immediately if planning or execution fails.

The FullSyncAgent must not run StationRunnerAgent if ExecutionAgent fails.

---

## GUI Execution Rules

The GUI must use the optimized full sync runner.

Preferred GUI execution:

```text
1. Build check
2. Full Sync
```

The GUI must not clean and rebuild dist on every run.

The GUI should build only if required compiled files are missing.

Required compiled file:

```text
dist/pipeline/fullSyncRunner.js
```

If build exists, GUI should show:

```text
Build skipped: existing build found
```

If build is missing, GUI should run:

```text
npm run build
```

The GUI must show clean phase-wise output.

The GUI must keep detailed logs in the log file.

The GUI must not show noisy internal logs unless debug mode is enabled.

---

## Logging Rules

Use plain text logs.

Do not use emojis because PowerShell GUI may show encoding issues.

Use indentation for step-level logs.

Detailed logs may include internal agent details.

GUI logs should show only clean progress summary.

GUI should show:

- build check
- plan summary
- area creation progress
- line creation progress
- machine creation batch progress
- operator creation batch progress
- station creation batch progress
- final completion status
- errors

GUI should hide:

- internal inventory loading details
- internal runtime context details
- risk level wording
- duplicate plan summaries
- debug-only messages

Detailed log files must still contain all technical logs.

---

## Progress Logging Rules

For long operations, the system must log visible progress.

Area progress:

```text
Areas to create: X
Areas created: X
```

Line progress:

```text
Lines to create: X
Lines created: X
```

Machine progress:

```text
Machines to create: X
Machines created in batch: X
Machines created: X
```

Operator progress:

```text
Operators to create: X
Operators created in batch: X
Operators created: X
```

Station progress:

```text
Stations created in batch: X
Stations checked: X
Stations created: X
Stations updated: X
```

This is required so users know the program is progressing and not stuck.

---

## Safety Rules

Do not delete:

- Excel source file
- .env file
- source files
- package.json
- package-lock.json

Only delete:

- dist folder during explicit build cleanup
- temporary GUI .cmd runner files after run

The system must never delete production data in TiCon.

The system must never perform destructive actions unless a future approved rule explicitly allows it.

---

## Error Handling Rules

If any step fails, stop immediately.

Do not continue to the next phase after failure.

If SmartPlan fails, do not execute.

If ExecutionAgent fails, do not run StationRunnerAgent.

If StationRunnerAgent fails, mark full sync as failed.

Network read failures may be retried only for safe GET requests.

Write operations must not be blindly retried unless idempotency is guaranteed.

Errors must be logged clearly.

GUI must show a concise error.

Full log file must contain technical details.

---

## Approval Rules

For normal GUI operation, write operations are triggered by the user pressing Create.

The Create button is treated as user approval.

If future LLM-driven planning is enabled, the generated plan must be validated before execution.

If plan volume is unusually high, the system may warn in detailed logs.

The GUI should avoid showing risk wording unless explicitly requested.

---

## Agent Boundary Rules

Agents may:

- observe state
- build context
- plan actions
- validate plans
- explain decisions
- summarize progress
- suggest fixes

Agents must not:

- bypass validation
- directly call unsafe write APIs without ExecutionAgent
- delete TiCon data
- ignore Excel source of truth
- create template folders
- execute unvalidated LLM output

All TiCon write operations must flow through deterministic code.

---

## Debug Rules

Debug logs may be enabled using:

```text
LOG_LEVEL=debug
```

Debug logs may include:

- detailed agent decisions
- prompt text
- raw plan input
- raw validation details

Debug logs must not expose secrets.

Do not log:

- passwords
- tokens
- API keys
- full .env content

---

## Environment Rules

Required environment values must be loaded from `.env`.

The system must not modify `.env`.

Missing required environment values must fail fast with a clear error.

---

## LLM Token Rules

If no approved LLM API token is available, the system may use mock LLM output through:

```text
LLM_PLAN_RESPONSE
```

This allows testing the LLM planning pipeline without external API access.

If real LLM access is later approved, the LLM provider must be called only by the LLMPlanAgent.

The LLMPlanAgent must remain optional.

The deterministic planner must remain available as fallback.

---

## Final Non-Negotiable Rules

Excel is the source of truth.

PEH, MA, OP, and PRODUCT VARIANT must not be created by the application.

All write operations must be deterministic.

LLM may plan but must not execute.

Execution must be idempotent.

Failure must stop the pipeline.

Full logs must be preserved.

GUI logs must stay clean.