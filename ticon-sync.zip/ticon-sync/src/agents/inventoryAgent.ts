type FolderIndex = {
  folders: any[];
  folderByUid: Map<string, any>;
  folderKeySet: Set<string>;
  folderUidByKey: Map<string, string>;
};

const API = {
  FOLDERS: "/ticon-web/services/data/folders",
  MACHINES: "/ticon-web/services/data/resource-machine-elements",
  OPERATORS: "/ticon-web/services/data/resource-operator-elements"
};

const RETRY_DELAYS_MS = [1000, 2000, 4000];

export function isTransientNetworkError(err: any): boolean {
  const code = String(err?.code || "").toUpperCase();
  const status = Number(err?.response?.status || 0);

  if (status === 401 || status === 403) {
    return false;
  }

  if (
    code === "ECONNRESET" ||
    code === "ETIMEDOUT" ||
    code === "ECONNABORTED" ||
    code === "EAI_AGAIN" ||
    code === "ENOTFOUND" ||
    code === "ECONNREFUSED"
  ) {
    return true;
  }

  return status === 502 || status === 503 || status === 504;
}

export function delay(ms: number): Promise<void> {
  return new Promise(resolve => {
    setTimeout(resolve, ms);
  });
}

async function getWithRetry(
  api: any,
  url: string,
  params: Record<string, any>,
  label: string
): Promise<any> {
  let lastError: any = null;

  for (let attempt = 1; attempt <= RETRY_DELAYS_MS.length + 1; attempt += 1) {
    try {
      return await api.get(url, { params });
    } catch (err: any) {
      lastError = err;

      const transient = isTransientNetworkError(err);
      const hasNextAttempt = attempt <= RETRY_DELAYS_MS.length;

      if (!transient || !hasNextAttempt) {
        throw lastError;
      }

      const waitMs = RETRY_DELAYS_MS[attempt - 1];
      const code = err?.code ? ` code=${String(err.code)}` : "";
      const status = err?.response?.status ? ` status=${String(err.response.status)}` : "";
      const message = err?.message ? ` message=${String(err.message)}` : "";

      console.log(
        `[InventoryAgent] Retry ${attempt}/${RETRY_DELAYS_MS.length} for ${label}; waiting ${waitMs}ms;${code}${status}${message}`
      );

      await delay(waitMs);
    }
  }

  throw lastError || new Error(`[InventoryAgent] GET failed for ${label}`);
}

export async function fetchAll(
  api: any,
  url: string,
  extraParams: Record<string, any> = {}
): Promise<any[]> {
  const pageSize = 500;
  let skip = 0;
  const all: any[] = [];

  while (true) {
    const params = {
      pageSize,
      skip,
      ...extraParams
    };

    const label = `${url} skip=${skip}`;
    const res = await getWithRetry(api, url, params, label);

    const data = res.data?.entities || [];
    all.push(...data);

    if (data.length < pageSize) {
      break;
    }

    skip += pageSize;
  }

  return all;
}

export function buildFolderIndex(folders: any[]): FolderIndex {
  const folderByUid = new Map<string, any>();
  const folderKeySet = new Set<string>();
  const folderUidByKey = new Map<string, string>();

  for (const folder of folders) {
    const key = `${folder.code}|${folder.parentFolderUid}`;

    folderByUid.set(folder.uid, folder);
    folderKeySet.add(key);
    folderUidByKey.set(key, folder.uid);
  }

  return {
    folders,
    folderByUid,
    folderKeySet,
    folderUidByKey
  };
}

export function buildCodeSet(items: any[]): Set<string> {
  const codeSet = new Set<string>();

  for (const item of items) {
    if (item.code) {
      codeSet.add(item.code);
    }
  }

  return codeSet;
}

export async function loadFolderInventory(api: any): Promise<any[]> {
  console.log("[InventoryAgent] Loading folder inventory");
  const folders = await fetchAll(api, API.FOLDERS);
  console.log(`[InventoryAgent] Folder inventory loaded: ${folders.length}`);
  return folders;
}

export async function loadMachineInventory(
  api: any,
  folderpath: string
): Promise<any[]> {
  console.log(`[InventoryAgent] Loading machine inventory for ${folderpath}`);
  const machines = await fetchAll(api, API.MACHINES, { folderpath });
  console.log(`[InventoryAgent] Machine inventory loaded: ${machines.length}`);
  return machines;
}

export async function loadOperatorInventory(
  api: any,
  folderpath: string
): Promise<any[]> {
  console.log(`[InventoryAgent] Loading operator inventory for ${folderpath}`);
  const operators = await fetchAll(api, API.OPERATORS, { folderpath });
  console.log(`[InventoryAgent] Operator inventory loaded: ${operators.length}`);
  return operators;
}
