import { mkdirSync, writeFileSync } from "fs";
import {
  fetchAll,
  loadFolderInventory,
  buildFolderIndex,
  buildCodeSet,
  loadMachineInventory,
  loadOperatorInventory
} from "./inventoryAgent";
import { resolveTemplateStructure } from "./templateStructureAgent";

// ---------- FOLDER INVENTORY CACHE ----------
const FOLDER_CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes
let cachedFolders: any[] | null = null;
let cachedFolderLoadedAt: number = 0;

async function getFolderInventory(api: any): Promise<any[]> {
  const now = Date.now();

  if (cachedFolders && now - cachedFolderLoadedAt < FOLDER_CACHE_TTL_MS) {
    console.log("[RuntimeContextAgent] Using cached folder inventory");
    return cachedFolders;
  }

  const folders = await loadFolderInventory(api);
  cachedFolders = folders;
  cachedFolderLoadedAt = now;

  return folders;
}

function writeRuntimeContextArtifact(
  rootUid: string,
  pehFolderUid: string,
  maFolderUid: string,
  opFolderUid: string,
  pehPath: string,
  machinePath: string,
  operatorPath: string
): void {
  try {
    mkdirSync("artifacts", { recursive: true });

    const artifact = {
      rootUid,
      pehFolderUid,
      maFolderUid,
      opFolderUid,
      pehPath,
      machinePath,
      operatorPath,
      createdAt: new Date().toISOString()
    };

    const filename = `artifacts/runtimeContext_${rootUid}.json`;
    writeFileSync(filename, JSON.stringify(artifact, null, 2));
    console.log(`[RuntimeContextAgent] Runtime context artifact written to ${filename}`);
  } catch (err: any) {
    console.log(`[RuntimeContextAgent] Warning: Could not write artifact: ${err.message}`);
  }
}

export async function fetchRuntimeEntities(
  api: any,
  url: string,
  extraParams: Record<string, any> = {},
  label = "runtime entities"
): Promise<any[]> {
  console.log(`[RuntimeContextAgent] Loading ${label}`);
  const entities = await fetchAll(api, url, extraParams);
  console.log(`[RuntimeContextAgent] Loaded ${entities.length} ${label}`);
  return entities;
}

// ---------- OPTIONS ----------
export interface RuntimeContextOptions {
  includeMachines?: boolean;
  includeOperators?: boolean;
}

// ---------- RUNTIME CONTEXT ----------
export interface RuntimeContext {
  rootUid: string;
  folders: any[];
  folderByUid: Map<string, any>;
  folderKeySet: Set<string>;
  folderUidByKey: Map<string, string>;
  pehFolder: any;
  maFolder: any;
  opFolder: any;
  pehPath: string;
  machinePath: string;
  operatorPath: string;
  machines: any[];
  operators: any[];
  machineSet: Set<string>;
  operatorSet: Set<string>;
}

// ---------- LOAD RUNTIME CONTEXT ----------
export async function loadRuntimeContext(
  api: any,
  rootUid: string,
  options?: RuntimeContextOptions
): Promise<RuntimeContext> {
  // Normalize rootUid to accept both "15181" and "Folder-15181"
  if (rootUid && !rootUid.startsWith("Folder-")) {
    rootUid = `Folder-${rootUid}`;
  }

  console.log("[RuntimeContextAgent] Loading runtime context");
  console.log(`[RuntimeContextAgent] Root UID: ${rootUid}`);

  // Load folder inventory with cache
  const folders = await getFolderInventory(api);

  // Build folder index
  console.log("[RuntimeContextAgent] Building folder index");
  const folderIndex = buildFolderIndex(folders);

  // Resolve template structure
  console.log("[RuntimeContextAgent] Resolving template structure");
  const templateStructure = resolveTemplateStructure(folders, rootUid);

  // Write runtime context artifact
  writeRuntimeContextArtifact(
    rootUid,
    templateStructure.pehFolder.uid,
    templateStructure.maFolder.uid,
    templateStructure.opFolder.uid,
    templateStructure.pehPath,
    templateStructure.machinePath,
    templateStructure.operatorPath
  );

  // Load machines if requested
  let machines: any[] = [];
  let machineSet = new Set<string>();

  if (options?.includeMachines) {
    console.log("[RuntimeContextAgent] Loading machines");
    machines = await loadMachineInventory(api, templateStructure.machinePath);
    machineSet = buildCodeSet(machines);
    console.log(`[RuntimeContextAgent] Loaded ${machines.length} machines`);
  }

  // Load operators if requested
  let operators: any[] = [];
  let operatorSet = new Set<string>();

  if (options?.includeOperators) {
    console.log("[RuntimeContextAgent] Loading operators");
    operators = await loadOperatorInventory(api, templateStructure.operatorPath);
    operatorSet = buildCodeSet(operators);
    console.log(`[RuntimeContextAgent] Loaded ${operators.length} operators`);
  }

  console.log("[RuntimeContextAgent] Runtime context loaded successfully");

  return {
    rootUid,
    folders: folderIndex.folders,
    folderByUid: folderIndex.folderByUid,
    folderKeySet: folderIndex.folderKeySet,
    folderUidByKey: folderIndex.folderUidByKey,
    pehFolder: templateStructure.pehFolder,
    maFolder: templateStructure.maFolder,
    opFolder: templateStructure.opFolder,
    pehPath: templateStructure.pehPath,
    machinePath: templateStructure.machinePath,
    operatorPath: templateStructure.operatorPath,
    machines,
    operators,
    machineSet,
    operatorSet
  };
}
