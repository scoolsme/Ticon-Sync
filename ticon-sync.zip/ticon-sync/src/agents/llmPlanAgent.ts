import * as fs from "fs";
import * as path from "path";
import type { PlanItem } from "../pipeline/smartPlan";

/**
 * Input shape for generatePlanWithLLM
 */
interface LLMPlanInput {
  areas: string[];
  lines: { code: string; parentCode?: string }[];
  machines: string[];
  operators: string[];
  existingContext: {
    areas: string[];
    lines: string[];
    machines: string[];
    operators: string[];
  };
}

/**
 * Raw LLM response item before validation
 */
interface LLMResponseItem {
  type?: string;
  code?: string;
  parentCode?: string;
  action?: string;
}

/**
 * Parsed LLM response structure
 */
interface LLMResponse {
  items?: LLMResponseItem[];
}

/**
 * Read project rules from CLAUDE.md
 */
function readProjectRules(): string {
  const claudePath = path.join(process.cwd(), "src", "CLAUDE.md");
  const rules = fs.readFileSync(claudePath, "utf-8");
  return rules;
}

/**
 * Clean JSON text by removing UTF-8 BOM and invisible leading characters
 * This handles files created by PowerShell Out-File which may include BOM
 */
function cleanJsonText(text: string): string {
  // Remove UTF-8 BOM if present
  let cleaned = text.replace(/^\uFEFF/, "");
  // Trim leading and trailing whitespace
  cleaned = cleaned.trim();
  return cleaned;
}

/**
 * Get LLM response text from environment variable or file
 * Uses mock LLM response mode since no API token is approved yet.
 * No external LLM APIs are called.
 * 
 * Priority:
 * 1. LLM_PLAN_RESPONSE_FILE (if set, read from file)
 * 2. LLM_PLAN_RESPONSE (if set, use inline)
 * 3. Error if neither is set
 */
function getLLMResponseText(prompt: string): string {
  let mockResponse: string | undefined;

  // Check for file-based mock response first (preferred)
  if (process.env.LLM_PLAN_RESPONSE_FILE) {
    try {
      mockResponse = fs.readFileSync(process.env.LLM_PLAN_RESPONSE_FILE, "utf-8");
      mockResponse = cleanJsonText(mockResponse);
      console.log("[LLMPlanAgent] Using mock LLM response from file");
    } catch (error: any) {
      throw new Error(
        `[LLMPlanAgent] Failed to read mock LLM response file: ${process.env.LLM_PLAN_RESPONSE_FILE}. ` +
          `Error: ${error.message}`
      );
    }
  } else if (process.env.LLM_PLAN_RESPONSE) {
    // Fall back to inline mock response
    mockResponse = cleanJsonText(process.env.LLM_PLAN_RESPONSE);
    console.log("[LLMPlanAgent] Using mock LLM response");
  }

  if (!mockResponse) {
    throw new Error(
      "[LLMPlanAgent] Missing mock LLM response configuration. " +
        "Set one of: LLM_PLAN_RESPONSE_FILE (path to JSON file) or LLM_PLAN_RESPONSE (inline JSON). " +
        'Example: LLM_PLAN_RESPONSE=\'{"items":[{"type":"AREA","code":"A1","action":"CREATE"}]}\' ' +
        "for enterprise/offline testing mode."
    );
  }

  if (process.env.LOG_LEVEL === "debug") {
    console.log("[LLMPlanAgent] Generated prompt:\n" + prompt);
  }

  return mockResponse;
}

/**
 * Validate that a value is one of the allowed values
 */
function validateEnum<T>(
  value: unknown,
  allowed: readonly T[],
  fieldName: string
): asserts value is T {
  if (!allowed.includes(value as T)) {
    throw new Error(
      `[LLMPlanAgent] Invalid ${fieldName}: "${value}". ` +
        `Allowed values: ${allowed.join(", ")}`
    );
  }
}

/**
 * Validate a single parsed item from LLM response
 */
function validateItem(
  item: LLMResponseItem,
  input: LLMPlanInput
): {
  type: "AREA" | "LINE" | "MACHINE" | "OPERATOR";
  code: string;
  parentCode?: string;
  action: "CREATE" | "EXISTS";
} {
  // Validate type
  if (!item.type) {
    throw new Error("[LLMPlanAgent] Item missing required field: type");
  }
  validateEnum(
    item.type,
    ["AREA", "LINE", "MACHINE", "OPERATOR"] as const,
    "type"
  );
  const type = item.type as "AREA" | "LINE" | "MACHINE" | "OPERATOR";

  // Validate code
  if (!item.code) {
    throw new Error("[LLMPlanAgent] Item missing required field: code");
  }
  if (typeof item.code !== "string" || item.code.trim() === "") {
    throw new Error(
      "[LLMPlanAgent] Item code must be a non-empty string, " +
        `got: "${item.code}"`
    );
  }
  const code = item.code.trim();

  // Validate action
  if (!item.action) {
    throw new Error("[LLMPlanAgent] Item missing required field: action");
  }
  validateEnum(
    item.action,
    ["CREATE", "EXISTS"] as const,
    "action"
  );
  let action = item.action as "CREATE" | "EXISTS";

  // Validate LINE has parentCode
  if (type === "LINE" && !item.parentCode) {
    throw new Error(
      `[LLMPlanAgent] LINE item "${code}" missing required field: parentCode`
    );
  }
  const parentCode = item.parentCode ? item.parentCode.trim() : undefined;

  // Smart action determination based on existingContext
  // Never trust the LLM action blindly; force based on existingContext
  let sourceArray: string[] | undefined;
  switch (type) {
    case "AREA":
      sourceArray = input.existingContext.areas;
      break;
    case "LINE":
      sourceArray = input.existingContext.lines;
      break;
    case "MACHINE":
      sourceArray = input.existingContext.machines;
      break;
    case "OPERATOR":
      sourceArray = input.existingContext.operators;
      break;
  }

  if (sourceArray && sourceArray.includes(code)) {
    action = "EXISTS";
  } else {
    action = "CREATE";
  }

  return { type, code, parentCode, action };
}

/**
 * Validate that all input items are present in response
 */
function validateAllInputsPresent(
  parsedItems: ReturnType<typeof validateItem>[],
  input: LLMPlanInput
): void {
  const responseCodes = new Map<string, string[]>();

  for (const item of parsedItems) {
    if (!responseCodes.has(item.type)) {
      responseCodes.set(item.type, []);
    }
    responseCodes.get(item.type)!.push(item.code);
  }

  // Check areas
  for (const area of input.areas) {
    const areaCodes = responseCodes.get("AREA") || [];
    if (!areaCodes.includes(area)) {
      throw new Error(
        `[LLMPlanAgent] Expected AREA "${area}" not found in LLM response`
      );
    }
  }

  // Check lines
  for (const line of input.lines) {
    const lineCodes = responseCodes.get("LINE") || [];
    if (!lineCodes.includes(line.code)) {
      throw new Error(
        `[LLMPlanAgent] Expected LINE "${line.code}" not found in LLM response`
      );
    }
  }

  // Check machines
  for (const machine of input.machines) {
    const machineCodes = responseCodes.get("MACHINE") || [];
    if (!machineCodes.includes(machine)) {
      throw new Error(
        `[LLMPlanAgent] Expected MACHINE "${machine}" not found in LLM response`
      );
    }
  }

  // Check operators
  for (const operator of input.operators) {
    const operatorCodes = responseCodes.get("OPERATOR") || [];
    if (!operatorCodes.includes(operator)) {
      throw new Error(
        `[LLMPlanAgent] Expected OPERATOR "${operator}" not found in LLM response`
      );
    }
  }
}

/**
 * Validate that response does not contain unexpected codes
 */
function validateNoUnexpectedCodes(
  parsedItems: ReturnType<typeof validateItem>[],
  input: LLMPlanInput
): void {
  const allowedAreas = new Set(input.areas);
  const allowedLines = new Set(input.lines.map((l) => l.code));
  const allowedMachines = new Set(input.machines);
  const allowedOperators = new Set(input.operators);

  for (const item of parsedItems) {
    switch (item.type) {
      case "AREA":
        if (!allowedAreas.has(item.code)) {
          throw new Error(
            `[LLMPlanAgent] Unexpected AREA "${item.code}" in LLM response. ` +
              `Allowed areas: ${Array.from(allowedAreas).join(", ")}`
          );
        }
        break;
      case "LINE":
        if (!allowedLines.has(item.code)) {
          throw new Error(
            `[LLMPlanAgent] Unexpected LINE "${item.code}" in LLM response. ` +
              `Allowed lines: ${Array.from(allowedLines).join(", ")}`
          );
        }
        break;
      case "MACHINE":
        if (!allowedMachines.has(item.code)) {
          throw new Error(
            `[LLMPlanAgent] Unexpected MACHINE "${item.code}" in LLM response. ` +
              `Allowed machines: ${Array.from(allowedMachines).join(", ")}`
          );
        }
        break;
      case "OPERATOR":
        if (!allowedOperators.has(item.code)) {
          throw new Error(
            `[LLMPlanAgent] Unexpected OPERATOR "${item.code}" in LLM response. ` +
              `Allowed operators: ${Array.from(allowedOperators).join(", ")}`
          );
        }
        break;
    }
  }
}

/**
 * Sort plan items deterministically:
 * 1. By type order: AREA, LINE, MACHINE, OPERATOR
 * 2. Alphabetically by code within each type
 */
function sortPlanItems(items: PlanItem[]): PlanItem[] {
  const typeOrder = { AREA: 0, LINE: 1, MACHINE: 2, OPERATOR: 3 };

  return [...items].sort((a, b) => {
    const typeCompare = typeOrder[a.type] - typeOrder[b.type];
    if (typeCompare !== 0) return typeCompare;

    return a.code.localeCompare(b.code);
  });
}

/**
 * Generate a plan using mock LLM response mode.
 * Reads project rules from src/CLAUDE.md and processes them through a mock LLM.
 *
 * @param input - Planning input with areas, lines, machines, operators, and existing context
 * @returns Validated and sorted PlanItem array
 */
export async function generatePlanWithLLM(
  input: LLMPlanInput
): Promise<PlanItem[]> {
  console.log("[LLMPlanAgent] Generating plan with LLM");

  // Read project rules
  const projectRules = readProjectRules();

  // Build prompt with clear instructions
  const prompt = buildPrompt(projectRules, input);

  // Get mock LLM response
  const responseText = getLLMResponseText(prompt);

  // Parse JSON response
  let parsedResponse: LLMResponse;
  try {
    const cleanedText = cleanJsonText(responseText);
    parsedResponse = JSON.parse(cleanedText);
  } catch (error) {
    throw new Error(
      `[LLMPlanAgent] Failed to parse LLM response as JSON. ` +
        `Response: ${responseText}. ` +
        `Error: ${error instanceof Error ? error.message : String(error)}`
    );
  }

  if (!parsedResponse.items || !Array.isArray(parsedResponse.items)) {
    throw new Error(
      `[LLMPlanAgent] LLM response missing required field: items (must be array). ` +
        `Got: ${JSON.stringify(parsedResponse)}`
    );
  }

  // Validate and convert all items
  const parsedItems = parsedResponse.items.map((item) =>
    validateItem(item, input)
  );

  // Validate all inputs are present in response
  validateAllInputsPresent(parsedItems, input);

  // Validate no unexpected codes
  validateNoUnexpectedCodes(parsedItems, input);

  // Convert to PlanItem type
  const planItems: PlanItem[] = parsedItems.map((item) => ({
    type: item.type,
    code: item.code,
    parentCode: item.parentCode,
    action: item.action
  }));

  // Sort deterministically
  const sortedPlan = sortPlanItems(planItems);

  console.log(
    `[LLMPlanAgent] Generated plan with ${sortedPlan.length} items`
  );

  return sortedPlan;
}

/**
 * Build the prompt for the mock LLM
 */
function buildPrompt(projectRules: string, input: LLMPlanInput): string {
  const inputJson = JSON.stringify(input, null, 2);

  return `You are the LLMPlanAgent for the TiCon Sync system.

## Project Rules

${projectRules}

## Input Data

The planning input contains these items to sync:

\`\`\`json
${inputJson}
\`\`\`

## Your Task

Generate a plan for syncing these items into TiCon based on the project rules.

## Output Format

You MUST respond with ONLY a valid JSON object in this exact format. No markdown, no code blocks, no explanations:

\`\`\`json
{
  "items": [
    {
      "type": "AREA" | "LINE" | "MACHINE" | "OPERATOR",
      "code": "string (required, non-empty)",
      "parentCode": "string (optional, required only for LINE type)",
      "action": "CREATE" | "EXISTS"
    }
  ]
}
\`\`\`

## Rules for Response

1. Include all input areas, lines, machines, and operators in the response.
2. Set action to "CREATE" for items missing from existing context.
3. Set action to "EXISTS" for items already in existing context.
4. For LINE items, always include parentCode pointing to the area it belongs to.
5. Do not include any items not in the input.
6. Do not add explanations or markdown - output ONLY the JSON object.
`;
}
