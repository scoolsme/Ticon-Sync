import { AxiosInstance } from "axios";

// Helper
function entities<T>(data: any): T[] {
  return Array.isArray(data?.entities) ? data.entities : [];
}

// Get folders by code
export async function getFoldersByCode(api: AxiosInstance, code: string) {
  const res = await api.get("/ticon-web/services/data/folders", {
    params: { code }
  });
  return entities<any>(res.data);
}

// Pick correct folder
export function pickByParent(folders: any[], parentUid?: string) {
  if (!parentUid) {
    if (folders.length === 1) return folders[0];
    return null;
  }

  return folders.find(f => f.parentFolderUid === parentUid) || null;
}

// ✅ Your main function
export async function ensureFolder(
  api: AxiosInstance,
  code: string,
  parentUid: string,
  description: string,
  dryRun: boolean = true
) {

  const existingFolders = await getFoldersByCode(api, code);
  const existing = pickByParent(existingFolders, parentUid);

  if (existing) {
    console.log(`✅ Folder EXISTS: ${code} (${existing.uid})`);
    return existing;
  }

  if (dryRun) {
    console.log(`⚠️ DRY-RUN: Folder would be created → ${code}`);
    return null;
  }

  console.log(`➕ Creating folder: ${code}`);

  await api.post("/ticon-web/services/data/folders", [
    {
      Code: code,
      parentfolderUid: parentUid,
      Description: {
        language: "en-US",
        text: description
      }
    }
  ]);

  const afterCreate = await getFoldersByCode(api, code);
  const created = pickByParent(afterCreate, parentUid);

  if (!created) {
    throw new Error(`❌ Failed to create folder: ${code}`);
  }

  return created;
}
``