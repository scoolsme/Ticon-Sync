import axios from "axios";
import https from "https";

export function createTiconClient() {
  const baseURL = process.env.TICON_BASE_URL;
  const username = process.env.TICON_USERNAME;
  const password = process.env.TICON_PASSWORD;

  if (!baseURL || !username || !password) {
    throw new Error("Missing env vars. Please set TICON_BASE_URL, TICON_USERNAME, TICON_PASSWORD in .env");
  }

  const insecure = process.env.TICON_INSECURE_TLS === "true";

  return axios.create({
    baseURL,
    timeout: 720000, // increased timeout to 12 minutes
    auth: { username, password },
    httpsAgent: new https.Agent({
      rejectUnauthorized: !insecure
    }),
    headers: { "Content-Type": "application/json" }
  });
}