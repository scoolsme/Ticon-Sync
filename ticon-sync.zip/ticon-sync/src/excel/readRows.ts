import * as XLSX from "xlsx";

export type Row = {
  areaCode: string;
  areaName: string;
  lineCode: string;
  lineName: string;
  workcenterCode: string;
  workstationName: string;        
  workstationSequence: number;    
  machineCode: string;
  operatorCode: string;
};

export function readRows(filePath: string): Row[] {
  const workbook = XLSX.readFile(filePath);
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const json: any[] = XLSX.utils.sheet_to_json(sheet);

  
if (process.env.LOG_LEVEL === "debug") {
  console.log("Sample Excel Row:", json[0]);
}

  

  return json.map((r) => ({
    areaCode: String(r["ProductionAreaId"] || "").trim(),
    areaName: String(r["Production Area Name"] || "").trim(),
    lineCode: String(r["ProductionLineID"] || "").trim(),
    lineName: String(r["ProductionLineName"] || "").trim(),
    workcenterCode: String(r["SAP Workcenter"] || "").trim(),
    workstationName: String(r["Workstation Name"] || "").trim(),
    workstationSequence: Number(r["Workstation Sequence"] || 1),
    machineCode: String(r["Equipment-LLL"] || "").trim(),
    operatorCode: String(r["Operator"] || "").trim()
  }));
}
