"use strict";
// ---------- TYPES ----------
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveTemplateStructure = resolveTemplateStructure;
// ---------- HELPERS ----------
function normalizeRootUid(uid) {
    if (uid && !uid.startsWith("Folder-")) {
        return `Folder-${uid}`;
    }
    return uid;
}
function buildFolderPath(uid, folderByUid) {
    const parts = [];
    let current = folderByUid.get(uid);
    while (current) {
        parts.unshift(current.code);
        current = folderByUid.get(current.parentFolderUid);
    }
    return "TiCon\\F\\" + parts.join("\\");
}
// ---------- AGENT ----------
class TemplateStructureAgent {
    constructor(folders, rootUid) {
        this.folders = folders;
        this.rootUid = rootUid;
        this.checks = [];
    }
    resolve() {
        this.log(`Resolving template structure for root ${this.rootUid}`);
        const folderByUid = this.buildFolderByUid();
        const pehFolder = this.findPeh();
        const maFolder = pehFolder ? this.findMa(pehFolder) : null;
        const opFolder = pehFolder ? this.findOp(pehFolder) : null;
        const riskLevel = this.calculateRiskLevel();
        if (riskLevel === "HIGH") {
            throw new Error(this.buildFailureMessage());
        }
        const pehPath = pehFolder
            ? buildFolderPath(pehFolder.uid, folderByUid)
            : "";
        const machinePath = pehPath ? `${pehPath}\\MA` : "";
        const operatorPath = pehPath ? `${pehPath}\\OP` : "";
        this.addCheck("Paths", "OK", `pehPath=${pehPath} machinePath=${machinePath} operatorPath=${operatorPath}`);
        this.log(`Risk level: ${riskLevel}`);
        return {
            rootUid: this.rootUid,
            pehFolder,
            maFolder,
            opFolder,
            folderByUid,
            pehPath,
            machinePath,
            operatorPath,
            checks: this.checks,
            riskLevel
        };
    }
    buildFolderByUid() {
        const map = new Map();
        for (const folder of this.folders) {
            map.set(folder.uid, folder);
        }
        this.addCheck("FolderInventory", this.folders.length > 0 ? "OK" : "FAILED", this.folders.length > 0
            ? `Loaded ${this.folders.length} folders`
            : "No folders supplied");
        return map;
    }
    findPeh() {
        const peh = this.folders.find(folder => folder.code === "PEH" &&
            folder.parentFolderUid === this.rootUid);
        if (!peh) {
            this.addCheck("PEHExists", "FAILED", `PEH not found under root ${this.rootUid}`);
            return null;
        }
        this.addCheck("PEHExists", "OK", `PEH found with uid ${peh.uid}`);
        return peh;
    }
    findMa(pehFolder) {
        const ma = this.folders.find(folder => folder.code === "MA" &&
            folder.parentFolderUid === pehFolder.uid);
        if (!ma) {
            this.addCheck("MAExists", "FAILED", `MA not found under PEH ${pehFolder.uid}`);
            return null;
        }
        this.addCheck("MAExists", "OK", `MA found with uid ${ma.uid}`);
        return ma;
    }
    findOp(pehFolder) {
        const op = this.folders.find(folder => folder.code === "OP" &&
            folder.parentFolderUid === pehFolder.uid);
        if (!op) {
            this.addCheck("OPExists", "FAILED", `OP not found under PEH ${pehFolder.uid}`);
            return null;
        }
        this.addCheck("OPExists", "OK", `OP found with uid ${op.uid}`);
        return op;
    }
    addCheck(name, status, detail) {
        this.checks.push({ name, status, detail });
        if (status !== "OK") {
            this.log(`${status} ${name}: ${detail}`);
        }
    }
    calculateRiskLevel() {
        if (this.checks.some(c => c.status === "FAILED")) {
            return "HIGH";
        }
        if (this.checks.some(c => c.status === "WARNING")) {
            return "MEDIUM";
        }
        return "LOW";
    }
    buildFailureMessage() {
        const failed = this.checks
            .filter(c => c.status === "FAILED")
            .map(c => `${c.name}: ${c.detail}`);
        return [
            "[TemplateStructureAgent] Template validation failed",
            ...failed
        ].join("\n");
    }
    log(message) {
        console.log(`[TemplateStructureAgent] ${message}`);
    }
}
// ---------- EXPORTED FUNCTION ----------
function resolveTemplateStructure(folders, rootUid) {
    const normalizedRootUid = normalizeRootUid(rootUid);
    const agent = new TemplateStructureAgent(folders, normalizedRootUid);
    return agent.resolve();
}
